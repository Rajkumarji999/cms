<!DOCTYPE html>
<html lang="en">
<head>
    <?php require_once("include/top.php");?>
</head>
<body>
  <?php require_once("include/header.php");?>
  
   <div class="jumbotron">
        <div class="container animated fadeInLeftBig">
        	<div id="jumbo" >
        		<h1>Costom<span class="headingclass">Post</span></h1>
        		<p>my name is Costom post page.</p>
        		
        	</div>
        	
        </div>
        <img src="image/rose-red-flower-37643.jpeg" >
   </div>
   <section>
   	<div class="container">
   	<div class="row">
   		<div class="col-md-8">
   	<?php
   	
   		if(isset($_GET['post_id']))
   		{
			$p_id=$_GET['post_id'];
			$q="UPDATE `posts` SET `views` = views+1 WHERE `posts`.`id` ='$p_id'";
				$r=mysqli_query($con,$q); 
			$one_post_query="select * from posts WHERE status= 'Publish' and id=$p_id"; 
           $one_post_run=mysqli_query($con,$one_post_query);
           if(mysqli_num_rows($one_post_run) > 0){
           	$post_row=mysqli_fetch_array($one_post_run);
           $post_id=$post_row['id'];
            $login_id=$post_row['login_id'];	
	$post_date=getdate($post_row['date']);
	$post_day=$post_date['mday'];
	$post_month=$post_date['month'];
	$post_year=$post_date['year'];
	$post_title=$post_row['title'];
	$post_author=$post_row['author'];
	$post_image=$post_row['image'];
	$post_categories=$post_row['categories'];
	$post_tags=$post_row['tags'];
	$post_data=$post_row['post_data'];
	$post_views=$post_row['views'];
	$post_status=$post_row['status'];
	$login_select="select * from login where Id= $login_id";
	$login_run=mysqli_query($con,$login_select);
	$login_row=mysqli_fetch_array($login_run);
	$log_id=$login_row['Id'];
	$post_author_image=$login_row['images'];
	$post_dec=$login_row['discripation'];
	}


else {
	header("location: index.php");
}

}

 ?>
   		<div class="post">
	<div class="row">
		<div class="col-md-2 post-date">
			<div class="day"><?php echo$post_day;?> </div>
			<div class="month"><?php echo$post_month;?> </div>
			<div class="year"><?php echo$post_year;?> </div>
		</div>
		<div class="col-md-8 post-title">
			<a href="post.php?post_id=<?php echo $p_id; ?>"><h2><?php echo ucfirst($post_title);?> </h2></a>
			<p>Written by: <span class="author"><?php echo ucfirst($post_author);?></span></p>
		</div>
		<div class="col-md-2 Profile-picture">
			<img src="images/<?php echo $post_author_image ;?>" alt="pro" class="img-circle "  height="70px" height="70px;">	 
		</div>
	</div>
	<div class="height">
	<a href="images/<?php echo $post_image ;?>"><img  src="images/<?php echo $post_image ;?>" alt="post image"/></a></div>
	<p class="desc"><?php echo ucfirst($post_data);?></p>
	<div class="bottom">
		<span class="frist"><i class="fa fa-folder"></i>&nbsp;<a href="#"><?php echo ucfirst($post_categories); ?></a></span>|<span class="sec"><i class="fa fa-comment"></i>&nbsp;<a href="#">Comment</a></span>
		
	</div>
	
</div>

<div class="releted-post">
	<div class="container">
		<h3>Releted-post</h3>
	</div>	
	<hr>
	<div class="row">
	<?php 
	

	$r_query="select * from posts WHERE status= 'Publish' and title like '%$post_title%' LIMIT 3  "; 
    $r_run=mysqli_query($con,$r_query);
    while($r_row=mysqli_fetch_array($r_run))
    {
		$r_id=$r_row['id'];
		$r_title=$r_row['title'];
		$r_img=$r_row['image'];
	
	?>
		<div class="col-md-4">
		<a href="post.php?post_id=<?php echo $r_id; ?>">
			<img src="images/<?php echo $r_img ; ?>" alt="" class="img-respnsive">
			<h4><?php echo$r_title;?> </h4></a>
		</div>
		<?php } ?>
	</div> 	
</div>
<div class="pupple">
	<div class="row">
		<div class="col-md-2 mar">
			<img src="images/<?php echo $post_author_image ;?>"  class="img-circle" >
		</div>
		<div class="col-md-10">
		<h4><?php echo ucfirst($post_author);?></h4>
			<p class="text-justify"><?php echo ucfirst($post_dec); ?></p>
		</div>
		<hr>
	</div>
</div>
<?php

$c_query="select * from comment WHERE status= 'approve' and post_id= '$p_id' ORDER BY id DESC";
$c_run=mysqli_query($con,$c_query);
if(mysqli_num_rows($c_run) > 0)
{
	
?>
<div class="comment"> 	
<h3>Comments</h3><hr>
<?php
while($c_row=mysqli_fetch_array($c_run))
{
	$cs_name=$c_row['name'];
	$cs_email=$c_row['email'];
	$cs_img=$c_row['image'];
	$cs_message=$c_row['comments'];
?>
	<div class="row" style="padding-bottom: 20px;">
		<div class="col-md-3">
			<img src="image/<?php echo $cs_img ; ?>">
		</div>
		<div class="col-md-9">
		<h4><?php echo ucfirst($cs_name);  ?></h4>
			<p class="text-justify"><?php echo ucfirst($cs_message) ; ?></p>
		</div>
		<hr>
	</div>	
	<?php } ?>
</div>
<?php } ?>
<div class="row">
<?php
$p_id=$_GET['post_id'];
if(isset($_POST['submit']))
{
	$c_name=$_POST['full-name'];
	$c_email=$_POST['email'];
	$c_web=$_POST['Wabside'];
	$c_message=$_POST['message'];
	$c_date=time();
if(empty($c_name) or empty($c_email) or empty($c_web) or empty($c_message))
{
	$error_msg="All (*) feilds are Required";
}
	else
	{
		$cs_query="INSERT INTO `comment` (`id`, `date`, `name`, `Username`, `post_id`, `email`, `website`, `image`, `comments`, `status`) VALUES (NULL, '$c_date', '$c_name', 'user', '$p_id', '$c_email', '$c_web', 'Me.png', '$c_message', 'Pending') ";
			if(mysqli_query($con,$cs_query))
			{
				$msg="Comment has submited and waiting for Approval";
				$c_name="";
				$c_email="";
				$c_web="";
				$c_message="";
			
			}
		else
		{
			$error_msg="Comment has not be submited";
		}

	}
}
	?>
<div class="col-md-12 contact-form bot">
   			<h2>Comments</h2>
   				<form action="" method="post" enctype="multipart/form-data">
   					<div class="form-group">
   						<label for="full-name">Full Name*</label>
   						<input type="text" name="full-name" value="<?php if(isset($c_name)){echo $c_name;} ?>" id="full-name" class="form-control" placeholder="Full Name" >
   					</div>
   					<div class="form-group">
   						<label for="email">Email*</label>
   						<input type="text" name="email"  value="<?php if(isset($c_email)){echo $c_email;} ?>"autocomplete="" id="email"class="form-control" placeholder="email" >
   					</div>
   					<div class="form-group">
   						<label for="Wabside">Wabside*</label>
   						<input type="text" name="Wabside" value="<?php if(isset($c_web)){echo $c_web;} ?>" id="Wabside"class="form-control" placeholder="Wabside" >
   					</div>
   					<div class="form-group">
   						<label for="message">Message</label>
   						<textarea name="message" id="message" class="form-control" rows="10" cols="10" placeholder="put the Message here...">
   							<?php if(isset($c_message)){echo $c_message;} ?>
   						</textarea> 
   						
   					</div>
   					<div class="form-group">
   						
   						<input type="submit" name="submit" class="btn btn-primary" value="Submit Post">
   						<?php
						if(isset($error_msg))
						{
						?>
						<span class="pull-right" style="color:red;">
						<?php
						echo $error_msg;
						?>
						</span>
						<?php
						}
						else if(isset($msg))
						{
						?>
						<span class="pull-right" style="color:green;">
						<?php
						echo $msg ;
						
						?>
						</span>
						<?php
					     }
						?>
					</div>
   				</form>
   			</div>
   		</div>
   		</div>
   		<div class="col-md-4">
   			<?php require_once("include/side-bar.php"); ?>
   			</div>
   			
   			</div>
   			</div>
   </section>
   <?php require_once("include/footer.php");?>
</body>
</html>
