<!DOCTYPE html>
<html lang="en">
<head>
    <?php require_once("include/top.php"); ?>
</head>
<body>
 <?php require_once("include/header.php"); ?>
   <div class="jumbotron">
        <div class="container animated fadeInLeftBig">
        	<div id="jumbo" >
        		<h1>Contact<span class="headingclass">us</span></h1>
        		<p>my name is Contact page.</p>
        		
        	</div>
        	
        </div>
        <img src="image/rose-red-flower-37643.jpeg" >
   </div>
   <section>
   	<div class="container">
   	<div class="row">
   		<div class="col-md-8">
   		<div class="row">
   			<div class="col-md-12">
   				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14247.65095159771!2d83.37516727366999!3d26.77905138741403!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39914501793dc6d1%3A0x9564df23ca34c541!2sBasharatpur%2C+Gorakhpur%2C+Uttar+Pradesh!5e0!3m2!1sen!2sin!4v1544167569004" width="100%" height="500px;" frameborder="0" style="border:0" allowfullscreen></iframe>
   			</div>
   			<div class="col-md-12 contact-form ">
   			<h2>Contact </h2>
   				<form action="" method="post" enctype="multipart/form-data">
   					<div class="form-group">
   						<label for="full-name">Full Name*</label>
   						<input type="text" name="full-name" id="full-name" class="form-control" placeholder="Full Name">
   					</div>
   					<div class="form-group">
   						<label for="email">Email*</label>
   						<input type="text" name="email"  id="email"class="form-control" placeholder="email">
   					</div>
   					<div class="form-group">
   						<label for="Wabside">Wabside</label>
   						<input type="text" name="Wabside" id="Wabside"class="form-control" placeholder="Wabside">
   					</div>
   					<div class="form-group">
   						<label for="message">Message</label>
   						<textarea name="message" id="message"class="form-control" rows="10" cols="10" placeholder="put the Message here..."></textarea> 
   						
   					</div>
   					<div class="form-group">
   						
   						<input type="submit" name="submit" class="btn btn-primary" value="Submit Post">
   					</div>
   				</form>
   			</div>
   		</div>
   		</div>
   		<div class="col-md-4">
   			<?php require_once("include/side-bar.php"); ?>	

   			</div>
   			
   			</div>
   			</div>
   </section>
   <footer>
   <?php require_once("include/footer.php"); ?>
   </footer>
</body>
</html>