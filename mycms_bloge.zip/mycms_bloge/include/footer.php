<footer>
   	<div class="container">
   		Copyright &copy; by <a href="">Rajkumar</a> .
   		All Right Reserved from 2019- <?php echo date('Y'); ?>.
   	</div>
   </footer>