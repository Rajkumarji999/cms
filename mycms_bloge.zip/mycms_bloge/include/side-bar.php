<div class="widget">
	<form action="" method="post" enctype="multipart/form-data">
   				<div class="input-group">
   					<input type="text" class="form-control"  name="serch" placeholder="search here.....">
   					<span class="input-group-btn">
   						<input type="submit" name="submit" class="btn btn-default" value="Go!">
   					</span>
   				</div>
		</form>
   			</div>
   			<div class="widget">
   				<div class="popular">
   					<h4>Popular Post</h4>
   					<hr>
   					<?php
   					$R_query="select * from posts WHERE status= 'Publish' order by views DESC LIMIT 5";
   					$R_run=mysqli_query($con,$R_query);
   					if(mysqli_num_rows($R_run) > 0)
   					{
   						
						while($r_row=mysqli_fetch_array($R_run))
						{
						$R_id=$r_row['id'];
   						$R_image=$r_row['image'];
   						$R_date=getdate($r_row['date']);
	                    $R_day=$R_date['mday'];
	                    $R_month=$R_date['month'];
	                    $R_year=$R_date['year'];
   						$R_title=$r_row['title'];
   						
						
						
   					?>
   					<div class="row">
   						<div class="col-xs-4">
                        <div class="hei">
   							<a href="post.php?post_id=<?php echo $R_id;  ?>"><img src="images/<?php echo $R_image; ?>"></a>
   						</div>
   						</div>
   						<div class="col-xs-8  data">
   							<a href="post.php?post_id=<?php echo $R_id;  ?>"><h4><?php echo $R_title; ?></h4></a>
   							<p><i class="fa fa-clock-o" ></i><?php echo $R_day.",".$R_month.",".$R_year;  ?></p>
   						</div>
   					</div>
   					<hr>
   					<?php	
						}
					}
					else
					{
						echo"No Post Here..." ;
					}
					?>
   					
   				</div>
   			</div>
<div class="widget">
   				<div class="popular">
   					<h4>Recent Post</h4>
   					<hr>
   					<?php
   					$R_query="select * from posts WHERE status= 'Publish' order by id DESC LIMIT 5";
   					$R_run=mysqli_query($con,$R_query);
   					if(mysqli_num_rows($R_run) > 0)
   					{
   						
						while($r_row=mysqli_fetch_array($R_run))
						{
						$R_id=$r_row['id'];
   						$R_image=$r_row['image'];
   						$R_date=getdate($r_row['date']);
	                    $R_day=$R_date['mday'];
	                    $R_month=$R_date['month'];
	                    $R_year=$R_date['year'];
   						$R_title=$r_row['title'];
   						
						
						
   					?>
   					<div class="row">
   						<div class="col-xs-4">
   						<div class="hei">
   							<a href="post.php?post_id=<?php echo $R_id; ?>"><img src="images/<?php echo $R_image; ?>"></a>
   						</div>
   						</div>
   						<div class="col-xs-8  data">
   							<a href="post.php?post_id=<?php echo $R_id; ?>"><h4><?php echo $R_title; ?></h4></a>
   							<p><i class="fa fa-clock-o" ></i><?php echo $R_day.",".$R_month.",".$R_year;  ?></p>
   						</div>
   					</div>
   					<hr>
   					<?php	
						}
					}
					else
					{
						echo"No Post Here..." ;
					}
					?>
   					
   				</div>
   			</div>
<div class="widget">
   				<div class="popular">
   					<h4>Categoies</h4>
   					<hr>
   					<div class="row">
   			<div class="col-xs-6">
   				<ul>
   				<?php 
   				$c_query="select *from categories";
   				$c_run=mysqli_query($con,$c_query);
   				if(mysqli_num_rows($c_run) > 0)
   				{  
   				    $count=2;
   				    while($c_row=mysqli_fetch_array($c_run))
   				    {
						$c_id=$c_row['id'];
					     $c_categoies=$c_row['categories'];
   					     $count=$count+1;
   					     if(($count%2 )== 1)
   					     {
						 	
						 
				?>
				<li><a href="index.php?cot=<?php echo $c_id; ?> "><?php echo ucfirst($c_categoies);?></a></li>
				<?php
				}
				}	
				}
				else{
					echo"No categoies here";
				}
   				?>
   				</ul>
   			</div>
   			<div class="col-xs-6">
   				<ul>
   					<?php 
   				$c_query="select *from categories";
   				$c_run=mysqli_query($con,$c_query);
   				if(mysqli_num_rows($c_run) > 0)
   				{  
   				    $count=2;
   				    while($c_row=mysqli_fetch_array($c_run))
   				    {
						$c_id=$c_row['id'];
					     $c_categoies=$c_row['categories'];
   					     $count=$count+1;
   					     if(($count%2 )== 0)
   					     {
						 	
						 
				?>
				<li><a href="index.php?cot=<?php echo $c_id; ?> "><?php echo ucfirst($c_categoies);?></a></li>
				<?php
				}
				}	
				}
				else{
					echo"No categoies here";
				}
   				?>
   				</ul>
   			</div>
   		</div>		 	
   					</div>
   				</div>
   				<div class="widget">
   				<div class="popular cat">
   					<h4>Social Icon</h4>
   					<hr>
   					<div class="row">
   						<div class="col-xs-4">
   							<a href="#"><img src="image/facebook.png"></a>		</div>
   						
   						<div class="col-xs-4">
   							<a href="#"><img src="image/google.png"></a>	
   						</div>
   						<div class="col-xs-4">
   							<a href="#"><img src="image/tiwteer.jpg"></a>	
   						</div>
   					</div>
   					<hr>
   					<div class="row">
   						<div class="col-xs-4">
   							<a href="#"><img src="image/pin.png"></a>		</div>
   						
   						<div class="col-xs-4">
   							<a href="#"><img src="image/google.png"></a>	
   						</div>
   						<div class="col-xs-4">
   							<a href="#"><img src="image/tiwteer.jpg"></a>	
   						</div>
   					</div>
   					
   					</div>
   				</div>	
