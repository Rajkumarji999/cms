<!DOCTYPE html>
<html lang="en">
<head>
    <?php require_once("include/top.php"); ?>
</head>
<body>
 <?php require_once("include/header.php");
 
 $number_of_post=3;
 if(isset($_GET['page']))
 {
 	$page=$_GET['page'];
 }
 else{
 	$page=1;
 }

 if(isset($_GET['cat']))
 {
 	$cat_id=$_GET['cat'];
 	$cat_query="select * from categories WHERE id= '$cat_id'";
 	$cat_run=mysqli_query($con,$cat_query);
 	$cat_row=mysqli_fetch_array($cat_run);
 	$cat_name=$cat_row['categories'];
 }

 if(isset($_POST['submit']))
{
	$serch=$_POST['serch'];
	$all_post_query="select * from posts WHERE status= 'Publish'"; 
	$all_post_query .="and tags like '%$serch%'";
	$all_post_run=mysqli_query($con,$all_post_query);
    $all_post= mysqli_num_rows( $all_post_run);
    $total_page=ceil($all_post/$number_of_post);
    $ALL_start_from=($page-1) * $number_of_post;
}
else{
	$all_post_query="select * from posts WHERE status= 'Publish'"; 
	if(isset($cat_name))
{
	$all_post_query .="and categories='$cat_name'";
}
 $all_post_run=mysqli_query($con,$all_post_query);
 $all_post= mysqli_num_rows( $all_post_run);
 $total_page=ceil($all_post/$number_of_post);
 $ALL_start_from=($page-1) * $number_of_post;
  } 
  ?>
 
   <div class="jumbotron">
        <div class="container animated fadeInLeftBig">
        	<div id="jumbo" >
        		<h1>Rajkumar<span class="headingclass">Blog</span></h1>
        		<p>my name is Rajkumar</p>
        		
        	</div>
        	
        </div>
        <img src="image/rose-red-flower-37643.jpeg" >
   </div>
   <section>
   	<div class="container">
   	<div class="row">
   		<div class="col-md-8">
   		<?php
   		$slider_query="select * from posts WHERE status= 'Publish' order by  id DESC LIMIT 5";
   		$slider_run= mysqli_query($con, $slider_query);
   		if(mysqli_num_rows($slider_run) > 0)
   		{
			$count=mysqli_num_rows($slider_run);
		
   		?>
   			<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    
   <?php 
   for($i=0;$i<$count;$i++)
   { 
   if($i==0)
   {
   	
  
   	?>
   	<li data-target="#carousel-example-generic" data-slide-to="<?php echo $i ;?>" class="active"></li>
   	<?php
   	 }
   	 else{
   	 	?>
   	 	<li data-target="#carousel-example-generic" data-slide-to="<?php echo $i ;?>" ></li>
	 <?php	
	 }
   }
   ?>
   
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
  <?php
  $i=0;
  while($slider_row=mysqli_fetch_array($slider_run))
  {
  	$slider_id=$slider_row['id'];
  	$slider_image=$slider_row['image'];
  	$slider_title=$slider_row['title'];
  	$i=$i+1;
  	if($i==1)
  	{
		
	
  ?>
    <div class="item active">
    <?php
    }
    else{
	?>
	 <div class="item ">
	<?php	
	}
 
    ?>
    <div class="hei">
      <img src="images/<?php echo $slider_image ;?>" class="img">
      <div class="carousel-caption">
    <h3><?php echo ucfirst($slider_title) ;?></h3>
      </div>
      </div>
    </div>
    <?php  }?>

  </div>

  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<?php 
}
if(isset($_POST['submit']))
{
	$serch=$_POST['serch'];
	$post_query="select * from posts WHERE status= 'Publish'"; 
    $post_query .="and tags like '%$serch%'";
	$post_query .="order by id DESC LIMIT $ALL_start_from,$number_of_post";
}
else
{
$post_query="select * from posts WHERE status= 'Publish' ";
if(isset($cat_name))
{
	$post_query .="and categories='$cat_name'";
}
	
$post_query .="order by id DESC LIMIT $ALL_start_from,$number_of_post";
	}
$post_run=mysqli_query($con,$post_query);
if(mysqli_num_rows($post_run) > 0)
{
	while($row=mysqli_fetch_array($post_run))
	{
	   $post_id=$row['id'];
            $login_id=$row['login_id'];	
	$post_date=getdate($row['date']);
	$post_day=$post_date['mday'];
	$post_month=$post_date['month'];
	$post_year=$post_date['year'];
	$post_title=$row['title'];
	$post_author=$row['author'];
	$post_image=$row['image'];
	$post_categories=$row['categories'];
	$post_tags=$row['tags'];
	$post_data=substr($row['post_data'],0,500);
	$post_views=$row['views'];
	$post_status=$row['status'];
	$login_select="select * from login where Id= $login_id";
	$login_run=mysqli_query($con,$login_select);
	$login_row=mysqli_fetch_array($login_run);
	$log_id=$login_row['Id'];
	$post_author_images=$login_row['images'];
	
 ?>
<div class="post">
	<div class="row">
		<div class="col-md-2 post-date">
			<div class="day"><?php echo $post_day; ?></div>
			<div class="month"><?php echo $post_month; ?></div>
			<div class="year"><?php echo $post_year; ?></div>
		</div>
		<div class="col-md-8 post-title">
			<a href="post.php?post_id=<?php echo $post_id; ?>"><h2><?php echo ucfirst($post_title); ?></h2></a>
			<p>Written by: <span class="author"><?php echo ucfirst($post_author); ?></span></p>
		</div>
		<div class="col-md-2 Profile-picture">
			<img src="images/<?php echo $post_author_images; ?>" alt="Author images" class="img-circle " >
		</div>
	</div>
	<div class="height">
	<a href="post.php?post_id=<?php echo $post_id; ?>"><img  src="images/<?php echo $post_image; ?>" alt="post image"/></a></div>
	<p class="desc"><?php echo ucfirst($post_data); ?></p>
	<a href="post.php?post_id=<?php echo $post_id; ?>" class="btn btn-primary">Read More...</a>
	<div class="bottom">
		<span class="frist"><i class="fa fa-folder"></i>&nbsp;<a href="#"><?php echo ucfirst($post_categories); ?></a></span>|<span class="sec"><i class="fa fa-comment"></i>&nbsp;<a href="#">Comment</a></span>
		
	</div>
</div>
<?php
}
}else
{
	echo"<center><h2>sorry not data yet</h2></center>";
}
?>

 
<nav aria-label="Page navigation" id="pagenation">
  <ul class="pagination">
    <?php 
    for($i=1; $i<=$total_page;$i++)
    {
		
		echo"<li class='".($page==$i ? 'active':'')."'><a href='index.php?page=".$i."&".(isset($cat_name)?"cat=$cat_id":'')."'>$i</a></li>";
		
	}
    ?>
  </ul>
</nav>
   		</div>
   		<div class="col-md-4">
   			<?php require_once("include/side-bar.php"); ?>	

   			</div>
   			
   			</div>
   			</div>
   </section>
   <?php require_once("include/footer.php");?>
</body>
</html>