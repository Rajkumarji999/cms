<?php
session_start();
if(isset($_SESSION['user']))
{
	

?>
<!doctype html>
<html>
<head>
<?php require_once("inc/top.php"); ?>
<style>
	.mt
	{
		margin-top:100px;
		 
	}
	td a{
		padding: 30px;
	}
</style>
</head>

<body>
<?php require_once("inc/header.php");?>
<div class="container-fluid my-fluid" >
	<div class="row">
		<?php require_once("inc/aside-bar.php"); ?>
		<div class="col-lg-9 leftm col-md-9  col-xs-12 " style="margin-top: 40px;">
			<div class="page-header">
			
  <h1>Deshboard <small>Subtext for header</small></h1>
</div>
	<ol class="breadcrumb">
  <li><a href="#"> <i class="fa fa-tachometer" aria-hidden="true"></i> Deshboard</a></li>

</ol>
     
		<hr>
		<div class="row">
			<div class="col-md-7">
			<?php
			 $ed=$_GET['edt'];
			if(isset($_POST['edit']))
			{
			$cat_name=$_POST['ecat'];
			$cat_up="UPDATE `categories` SET `categories` = '$cat_name' WHERE `categories`.`id` = '$ed'";
			$ins_run=mysqli_query($con,$cat_up);
			if($ins_run)
			{
			
				header('location:categories.php');
			}
			else{
				$error_msg="not data edit ";
			}
				
			}
					?>
					<?php if(isset($msg)){
	?>
	<div class="alert alert-success" role="alert"><?php echo $msg; ?></div>
	
	<?php 
	}
	else 
	if(isset($error_sms)){
		
		?>
		<div class="alert alert-danger" role="alert"><?php   echo $error_sms; ?></div>
	
	<?php } ?>
	
				<form action="" method="post" enctype="multipart/form-data">
			<div class="row">
				<div class="col-lg-4 ">
				
					<div class="form-group">
					<?php 
					if(isset($_GET['edt']))
					{
				       $edi=$_GET['edt'];
					$cat_quer="select * FROM categories WHERE id ='$edi' ";
					$cat_ru=mysqli_query($con,$cat_quer);
					$row_cat=mysqli_fetch_array($cat_ru);
				
					$cat_id=$row_cat['id'];
					$cat_ca=$row_cat['categories'];
							
					}
					?>	
						<input  type="text" name="ecat" class="form-control" value="<?php echo $cat_ca;?>"  required="" placeholder="Enter the Categories"/>
					</div>
				</div>
				<div class="col-lg-8">
					<input type="submit" name="edit" class="btn btn-success" value="Edit categories">
				</div>
				
			</div>
		</form>
			</div>
			<div class="col-md-5">
			<?php 
					$cat_query="select * FROM categories";
					$cat_run=mysqli_query($con,$cat_query);
					if(mysqli_num_rows($cat_run)>0)
					{
				
					
					?>
			
				<table class="table table-hover mt table-bordered">
			<thead align="center">
				<tr>
					<th>Sr #</th>
					<th>Cotegories</th>
					<th>Edit</th>
					<th>Delete</th>
				</tr>
			</thead>
			<tbody align="center">
				<?php 
				while($row_cat=mysqli_fetch_array($cat_run))
				{
					$cat_id=$row_cat['id'];
					$cat_cat=$row_cat['categories'];
				
				?>
				
				<tr>
					<td><?php echo $cat_id ; ?> </td>
					<td><?php echo $cat_cat ; ?></td>
					<td><a href="cot-edit.php?edt=<?php echo $cat_id;?>" ><i class="fa fa-pencil"></i></a></td>
					<?php 
					if(isset($_GET['c_id']))
					{
						$c_id=$_GET['c_id'];
						$delete_cat="DELETE FROM `categories` WHERE `categories`.`id` = '$c_id'";
						$d_run=mysqli_query($con,$delete_cat);
					}
					?>
					<td><a href="categories.php?c_id=<?php echo $cat_id ; ?>"><i class="fa fa-times"></i></a></td>
					
				</tr>
				<?php } ?>
			</tbody>
		</table>
		<?php } ?>
			</div>
		</div>
		
		</div>
		
			
		</div>
		
		</div>
		<?php require_once("inc/footer.php"); ?>
	
	

</body>
</html>
<?php
	}
else
{
	echo "<script>window.open('index.php','_self')</script>";
}
	?>