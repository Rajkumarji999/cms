<?php 
include('connect.php');

$de= $_GET['del'];
$s="DELETE FROM `login` WHERE `Id` = '$de'";
if(isset($_SESSION['user'])&& $_SESSION['role']== 'Administrater')
{
	
$run=mysqli_query($con,$s);
if($run)
{
	echo "<script>window.location='user.php';</script>";
}
else
{
	echo "error";
}
}
else
{
	header('location:Admin.php');
}

?>