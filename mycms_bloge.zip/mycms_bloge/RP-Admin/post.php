<?php
session_start();
$nam=$_SESSION['user'];
if(isset($_SESSION['user']))
{
	

?>
<!doctype html>
<html>
<head>
<?php require_once("inc/top.php");?>

</head>

<body>
<?php require_once("inc/header.php");?>
<div class="container-fluid my-fluid " >
	<div class="row">
		<?php require_once("inc/aside-bar.php");?>
				<form action="" method="post" enctype="multipart/form-data">
		<div class="col-lg-9 leftm col-md-9  col-xs-12 " style="margin-top: 40px;">
			<div class="page-header">
			
  <h1>Post <small>corrent post here</small></h1>
</div>
	<ol class="breadcrumb">
  <li><a href="#"> <i class="fa fa-reply-all" aria-hidden="true"></i> All Post</a></li>

</ol>
  
		<hr>
		<div class="row">


	<div class="col-lg-12 col-md-8 col-xs-12">
	

			
			<div class="row">
		<div class="col-md-6 col-xs-12 col-lg-8 ">
		<div class="row">
				<div class="col-lg-4 ">
					<div class="form-group">	
						<select class="form-control" id="delete"  name="delete">	
						<option >-Select-</option>
						<?php if(isset($_SESSION['user'])&& $_SESSION['role']== 'Administrater')
{
	?>
                       <option value="delete">Delete</option>
                
							<option value="Publish">Change to Publish</option>
							
							<option value="Drop">Change to Drop</option>
							
							<?php }?>
						</select>
					</div>
				</div>
				<div class="col-lg-8">
					<input type="submit" name="del" class="btn btn-success" value="Apply">
					<a href="new_post.php" class="btn btn-primary"> New Post</a>

				</div>
					
			</div>
		</div>
	<div class="col-md-6 col-xs-12 col-lg-4">
   			<div class="input-group">
   					<input type="text" class="form-control"  name="serch" placeholder="search here.....">
   					<span class="input-group-btn">
   						<input type="submit" name="submit" class="btn btn-default" value="Go!">
   					</span>
   				</div>	
	
	</div>
	</div>
<?php
				if(isset($_POST['del']))
				{
					
					$del= $_POST['delete'];
					if(isset($_POST['chek']))
					{
						$check =$_POST['chek'];
					for($i=0; $i<count($check); $i++)
					{
						 $c_id2 = $check[$i];	
						if('delete'== $del)
						 {
						 	$del_qu="delete from posts where id='$c_id2'";
						 	$run_d=mysqli_query($con,$del_qu);
						 }
			             else if('Publish'==$del){
						 	$pq="UPDATE `posts` SET `status` = 'Publish' WHERE `posts`.`id` = '$c_id2'";
				           $ar=mysqli_query($con,$pq);
						 }
						 else if('Drop'==$del)
						 {
						 	$dq="UPDATE `posts` SET `status` = 'Drop' WHERE `posts`.`id` = '$c_id2'";
				            $pr=mysqli_query($con,$dq);
						 }
					}
				}
					else{
						echo '<P style="color:red;">Please select row</P>';
					}
				
				}
				?>
		<h3>New Post</h3>
	</div>
	
	
	</div>
   		<?php 
			if(isset($_POST['submit']))
			{
				$cont=$_POST['serch'];
				$show_post_query="select * from posts WHERE";
				$show_post_query .=" tags like '%$cont%' or title like '%$cont%'";
				$show_post_query .="order by id DESC";
			}
			else{
				$show_post_query="select * from posts order by id DESC";
			}
	        $show_run=mysqli_query($con,$show_post_query);
	if(mysqli_num_rows($show_run) > 0)
	{
			?>
	<div class="table-responsive">
		<table class="table table-hover table-bordered">
			<thead>
				<tr align="center">
				    <th><input type="checkbox" name="chek" id="select_all"></th>
					<th>Date</th>
					<th>Post title</th>
					<th>Images</th>
					<th>Categories</th>
					<th>Author</th>
					<th>Tags</th>
					<th>Post updated date</th>
					<th>status</th>
					<th>Views</th>
					<th>Edit</th>
					<th>Delete</th>
				</tr>
			</thead>
			<tbody>
			<?php 
			    while($show_row=mysqli_fetch_array($show_run))
				{
		        $show_id=$show_row['id'];	
				$show_date=getdate($show_row['date']);
				$show_day=$show_date['mday'];
				$show_month=$show_date['month'];
				$show_year=$show_date['year'];
				$show_date=getdate($show_row['post_update_date']);
				$show_day1=$show_date['mday'];
				$show_month2=$show_date['month'];
				$show_year3=$show_date['year'];
				$show_title=$show_row['title'];
				$show_login_id=$show_row['login_id'];
				$show_author=$show_row['author'];
				$show_image=$show_row['image'];
				$show_categories=$show_row['categories'];
				$show_tags=$show_row['tags'];
				$show_data=$show_row['post_data'];
				$show_views=$show_row['views'];
				$show_status=$show_row['status'];
				?>
				<tr align="center">
					<td><input type="checkbox" name="chek[]" class="checkbox" value="<?php echo $show_id;?>"></td>
					<td><?php echo $show_day ;?>-<?php echo $show_month ;?>-<?php echo $show_year ;?></td>
					<td><?php echo ucfirst($show_title) ;?></td>
					<td><img src="../images/<?php echo $show_image ;?>" width="30px" height="30px"></td>
					<td><?php echo ucfirst($show_categories) ;?></td>
					<td><?php echo ucfirst($show_author) ;?></td>
					<td><?php echo ucfirst($show_tags) ;?></td>
					<td><?php echo $show_day1 ;?>-<?php echo $show_month2 ;?>-<?php echo $show_year3 ;?></td>
				<?php 
				if($show_status=="Drop")
				{
					
					?>
					<td style="color:red;"><?php echo ucfirst($show_status) ;?></td>
					<?php }
					else 
					{
						
					
 ?>
 <td style="color: green;"><?php echo ucfirst($show_status) ;?></td>
 <?php } ?>
					<td><i class="fa fa-eye"></i><?php echo $show_views ;?></td>
					<?php 
					$sq="select* from login where Email='$nam'";
					$sr=mysqli_query($con,$sq);
					$rus=mysqli_fetch_array($sr);
					 $id3=$rus['Id'];
					 if($id3==$show_login_id or $_SESSION['role']=='Administrater')
					 {
					 	
					 
					?>
					<td><a href="edit.php?upd=<?php echo $show_id;?>" ><i class="fa fa-pencil"></i></a></td>
					<?php } else 
					{
					
					?>
					<td><a href=""><i class="fa fa-pencil"></i></a></td>
					<?php }?>
					<td><a href="delete.php?de=<?php echo $show_id;?>" name="times"><i class="fa fa-times"></i></a></td>
				</tr>
				<?php } ?>
			</tbody>
		</table>
		</div>
		<?php }else
		{
			echo"<h2 style='color:red; text-align:center; margin-top:140px; margin-bottom:140px;'>Sorry no data yet !</h2>";
		} ?>
		
		
			</div>
			</form>
		</div>
		</div>
		
		<?php require_once("inc/footer.php");?>

	

</body>
</html>
<?php
	}
else
{
	echo "<script>window.open('index.php','_self')</script>";
}
	?>