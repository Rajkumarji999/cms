<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>reset</title>
	<link rel="stylesheet" type="text/css" href="../style.css"> 
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" href="js/bootstrap-3.3.7.js">
<style>
	.container
	{
		width: 30%;
		border: 1px solid gray;
		background:#505050 ;
	    margin-top: 150px;
	}
	@media(max-width:876px)
	{
	.container{
		width: 90%;
		border: 1px solid gray;
	    background:#505050;
	    margin-top: 150px;
	}
	
	}
	@media(max-width:900px)
	{
	.container{
		width: 90%;
		border: 1px solid gray;
	    background:#505050;
	    margin-top: 150px;
	}
	
	} 
	
	</style>
</head>
<body>
<div class="container imgx">
<div class="ml-4">
	<h3 class="text-center text-white">Reset password...</h3>
	<p><a href="index.php" class="text-white">Back...</a></p>
</div>
<div class="mt-4">
<?php
	include('../connect.php');
		
	
	
	if(isset($_POST['reset']))
	{
		$pass=$_POST['pass'];
		$s="select * from login where Email='$pass'";
		$run=mysqli_query($con,$s);
		
		$rows=mysqli_fetch_array($run);
		$em=$rows['Email'];
		$id=$rows['Id'];
		 if($pass==$em)
			{   
	?>
	<?php
if(isset($_POST['nreset']))
	{
	$fna=$_POST['pass1'];
	$fn=$_POST['pass2'];
	$v="UPDATE `login` SET ` `password` = '$fna' WHERE `login`.`Id` = '$id'";
		if($fna==$fn)
		{
			
		$run1=mysqli_query($con,$v);
		if($run1)
		{
			header('location:login.php');
		}
		}
		else{
			echo "<script>alert('Enter the same password')</script>";
		}
	}?>
			<form action="" method="POST">

		<input type="password" class="form-control" name="pass1" placeholder="Enter The new password">
		<br>
		<input type="password" class="form-control" name="pass2" placeholder="Enter The Re-password">
		<br>
		<label>
		<input type="submit" class="btn btn-primary" name="nreset" value="Reset now">
		</label>
	</form>
<?php
			}
		else
		{
			$msg ="<p style='color:red'>Email is not mach please try again !</p>";
			header('location:reset.php?msg=<?php echo $msg; ?>');
			

		}
		
	}else
	{
?>
	<form action="" method="POST">
	<?php if(isset($msg)){
		
	
		echo $msg;
}
	?>
	<input type="email" class="form-control" name="pass" placeholder="Enter The Email">
		<input type="hidden" name="$na">
		
		<br>
		<label>
		<input type="submit" class="btn btn-primary" name="reset" value="Chek Password">
		</label>
	</form>
<?php }?>
	</div>
	</div>

</body>
</html>
	
	