<?php
session_start();
$use=$_SESSION['user'];
if(isset($use))
{
	

?>
<!doctype html>
<html>
<head>
<?php 
require_once("inc/top.php");
?>
<style>
	.textme
	{
		resize: none;
	}
</style>
</head>

<body>
<?php require_once("inc/header.php"); ?>
<div class="container-fluid my-fluid " >
	<div class="row">
		<?php require_once("inc/aside-bar.php"); ?>
		<div class="col-lg-9 leftm col-md-9  col-xs-12 " style="margin-top: 40px;">
			<div class="page-header">
			
  <h1>Add Post <small>Subtext for header</small></h1>
</div>
	<ol class="breadcrumb">
  <li><a href="Admin.php"> <i class="fa fa-tachometer" aria-hidden="true"></i> Add Post</a></li>

</ol>
     
		<hr>
		<?php 
	
	 include('../connect.php');
	if(isset($_POST['submit']))
	{ 
		 $title=$_POST['title'];
		 $tag=$_POST['tags'];
		 $categories=$_POST['selectbox'];
		 $status=$_POST['statubox'];
		$post=$_POST['textarea'];
		$date=time();
		$file = $_FILES['file']['name'];
        $file_loc = $_FILES['file']['tmp_name'];
        $file_size = $_FILES['file']['size'];
        $file_type = $_FILES['file']['type'];
        move_uploaded_file($_FILES["file"]["tmp_name"],"../images/$file");
       if(isset($_SESSION['user']) )
{
 $select_user="SELECT * FROM `login`  WHERE name = '$use'" ;
	     $login_run=mysqli_query($con,$select_user);
	if($user_row=mysqli_fetch_array($login_run))
	{

$u_id=$user_row['Id'];
$u_name=$user_row['name'];
$u_image=$user_row['images'];
 }
$insert_query="INSERT INTO `posts` (`login_id`, `date`, `title`, `author`, `image`, `categories`, `tags`, `post_data`, `status`,`post_update_date`) VALUES ('$u_id','$date','$title','$u_name','$file','$categories',' $tag','$post','$status','$date')";
$insert_run=mysqli_query($con,$insert_query);
 if($insert_run)
	{
		echo "<script>window.location='post.php';</script>";
	}
	else
	{
		$error_sms="oh ! no your data is not post";
	}
	}
	}
	
	
 
	

	
	

	?>
			<form action="new_post.php" method="post" enctype="multipart/form-data">
				<div class="col-lg-12 ">
	<div  style="color:#ffff ; background-color: #ea6a15;">
	<h2 class="text-center text-bold">Add new Post</h2>
	</div>
	
	<div style="margin-top: 20px;">
	
	<?php if(isset($msg)){
		
		?>
		<div class="alert alert-danger" role="alert"><?php   echo $error_sms; ?></div>
	
	<?php } ?>
	
			<div class="form-group">
			<label>Title</label>
				<input  type="text" name="title"class="form-control"  required=""  placeholder="Enter Title"/>
			</div>
			<div class="form-group">
			<label>Tags</label>
				<input  type="text" name="tags" class="form-control" required=""  placeholder="Enter Tags" />
			</div>
				<div class="form-group">
			<label>Tags</label>
				<input  type="file" name="file" class="form-control" required=""  placeholder="Enter Tags" />
				
			</div>

				<div class="form-group">
			<label>Categories</label>
				<select name="selectbox" class="form-control" required="" >
              <option>choose the Categories</option>
              <?php 
              $C_query="select * from categories";
              $c_run=mysqli_query($con,$C_query);
              while($c_fetch=mysqli_fetch_array($c_run))
              {
			  	$c_cat=$c_fetch['categories'];
			 
              ?>
                 <option value="<?php echo ucfirst($c_cat); ?> "><?php echo ucfirst($c_cat); ?></option>
				  <?php  }?>
            </select>
			</div>
			<div class="form-group">
			<label>Status</label>
				<select name="statubox" class="form-control" required >
              <option>choose the Status</option>
              <?php if(isset($_SESSION['user'])&& $_SESSION['role']== 'Administrater')
{ ?>
                 <option value="Publish">Publish</option>
                 <?php } ?>
				  <option value="Drop">Drop</option>
            </select>
			</div>
			<div class="form-group">
			<label>Post data</label>
				<textarea name="textarea" class="form-control textme" id="taxtarea"rows="20" cols="20"></textarea>
			</div>
			
			<div class="form-group">
				<input  type="submit" name="submit" value="Add Post" class="btn btn-primary" />
			</div>
	
		</div>
			</div>
			</form>
			</div>
				
		</div>
		
			
		</div>
		
		</div>
		
	
		<?php require_once("inc/footer.php");  ?>
	<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
  

</body>
</html>
<?php
	}
else
{
	echo "<script>window.open('index.php','_self')</script>";
}
	?>