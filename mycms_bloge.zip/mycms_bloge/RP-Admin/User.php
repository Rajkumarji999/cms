<?php
session_start();
if(!isset($_SESSION['user']))
{
	header('location:index.php');
}
else if(isset($_SESSION['user'])&& $_SESSION['role'] == 'local')
{
			echo "<script>window.open('Admin.php','_self')</script>";
}
else
{
		
?>
<!doctype html>
<html>
<head>
<?php require_once("inc/top.php");?>
<style>
	
</style>
</head>

<body>
<?php require_once("inc/header.php");?>
<div class="container-fluid my-fluid" >
	<div class="row">
	
		<?php require_once("inc/aside-bar.php");?>
		
		<div class="col-lg-9 leftm col-md-9  col-xs-12 " style="margin-top: 40px;">
			<div class="page-header">
			
  <h1>User <small>Subtext for header</small></h1>
</div>
	<ol class="breadcrumb">
  <li><a href="#"> <i class="fa fa-user" aria-hidden="true"></i> User</a></li>
  
</ol>
    
		<hr>
		<form action="" method="post" enctype="multipart/form-data">
		<div class="row">

	
	<div class="col-lg-12 col-md-12 col-xs-12">
	

		<div class="row">
		<div class="col-md-6 col-xs-12 col-lg-8 ">
		<div class="row">
				<div class="col-lg-4 ">
					<div class="form-group">	
						<select class="form-control" id="delete"  name="delete">	
						<option >-Select-</option>
                       <option value="delete">Delete</option>
							<option value="Administrater">Change to Administrater</option>
							<option value="local">Change to local</option>
						</select>
					</div>
				</div>
				<div class="col-lg-8">
					<input type="submit" name="del" class="btn btn-success" value="Apply">
					<a href="Add_user.php" class="btn btn-primary"> New User</a>
				</div>
					
			</div>
		</div>
	<div class="col-md-6 col-xs-12 col-lg-4">
   			<div class="input-group">
   					<input type="text" class="form-control"  name="serch" placeholder="search here.....">
   					<span class="input-group-btn">
   						<input type="submit" name="submit" class="btn btn-default" value="Go!">
   					</span>
   				</div>	
	
	</div>
	</div>
		<?php
				if(isset($_POST['del']))
				{
				
					$del= $_POST['delete'];
					if(isset($_POST['chek']))
					{
						$check=$_POST['chek'];
						
					for($i=0; $i<count($check); $i++)
					{
						 $c_id2 = $check[$i];	
						if('delete'== $del)
						 {
						 	$del_qu="DELETE FROM `login` WHERE `login`.`Id` = '$c_id2'";
						 	$run_d=mysqli_query($con,$del_qu);
						 }
			             else if('local'==$del){
						 	$pq="UPDATE `login` SET `role` = 'local' WHERE `login`.`Id` = '$c_id2'";
				           $ar=mysqli_query($con,$pq);
						 }
						 else if('Administrater'==$del)
						 {
						 	$dq="UPDATE `login` SET `role` = 'Administrater' WHERE `login`.`Id` = '$c_id2'";
				            $pr=mysqli_query($con,$dq);
						 }
					}
				
					}else
					{
						echo '<P style="color:red;">please select row</P>';
					}
				
				}
				?>

	</div>
	
	</div>
		<?php    
	             
	             if(isset($_POST['submit']))
			{
				$cont=$_POST['serch'];
				$user_query="select * from login WHERE";
				$user_query .=" name like '%$cont%' or Email like '$cont'";
				$user_query .="order by id DESC";
			}
			else{
				$user_query="select * from login order by id DESC";
			}
					$user_run=mysqli_query($con,$user_query);
					if(mysqli_num_rows($user_run)>0)
					{
						
	             ?>
		<h3>All user </h3>
		<div class="table-responsive">
		
		<table class="table table-hover table-bordered ">
		
			<thead>
				<tr align="center">
				<th><input type="checkbox" id="select_all"></th>
					<th>Date</th>
					<th>Name</th>
					<th>date of borth</th>
					<th>Email</th>
					<th>password</th>
					<th>images</th>
					<th>Role</th>
					<th>update-date</th>
					<th>Edit</th>
					<th>Delete</th>
				</tr>
 			</thead>
			<tbody>
				<?php 
					while($user_fetch=mysqli_fetch_array($user_run))
					{ 
						$user_id=$user_fetch['Id'];
						$user_name=$user_fetch['name'];
						$user_email=$user_fetch['Email'];
						$user_role=$user_fetch['role'];
						$user_pass=$user_fetch['password'];
						$user_dob=$user_fetch['dob'];
						$user_dis=$user_fetch['discripation'];
						$user_img=$user_fetch['images'];
						$user_date=getdate($user_fetch['date']);
						$user_day=$user_date['mday'];
						$user_month=$user_date['month'];
						$user_year=$user_date['year'];
						$user_date1=getdate($user_fetch['update_date']);
						$user_day1=$user_date1['mday'];
						$user_month1=$user_date1['month'];
						$user_year1=$user_date1['year'];
				?>
				
				<tr align="center">
				<td><input type="checkbox" id="chek" value="<?php echo $user_id; ?>" name="chek[]" class="checkbox"></td>
					<td><?php echo $user_day; ?>-<?php echo $user_month; ?>-<?php echo $user_year; ?></td>
					<td><?php echo $user_name; ?></td>
					<td><?php echo $user_dob; ?></td>
					<td><?php echo $user_email; ?></td>
					<td>********</td>
					<td><img src="../images/<?php echo$user_img;?> "  height="50px;" width="50px;"></td>
					<?php if('Administrater'==$user_role)
					{
						?>
				
					<td style="color:green;"><?php echo $user_role;?></td>
					<?php }
					else
					{
						
					?>
					<td style="color:#1a1fe6;"><?php echo $user_role;?></td>
					<?php } ?>
				<td><?php echo $user_day1; ?>-<?php echo $user_month1; ?>-<?php echo $user_year1; ?></td>
					<td><a href="edit1.php?upd=<?php echo $user_id;?>" name="pencil"><i class="fa fa-pencil"></i></a></td>
					<td><a href="delete1.php?del=<?php echo $user_id;?>" name="times"><i class="fa fa-times"></i></a></td>
				</tr>
				<?php } ?>
			</tbody>
			
		</table>
		
</div>
		<?php }
		else
		{
			echo"<h2 style='color:red; text-align:center; margin-top:140px; margin-bottom:140px;'>Sorry no data yet !</h2>";
		}
		?>
		
		<hr>
		</form>
		</div>
		
			
		</div>
		
		</div>
		<?php require_once("inc/footer.php");?>
	

</body>
</html>
<?php }?>