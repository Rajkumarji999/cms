<?php
session_start();
if(isset($_SESSION['user']))
{
	

?>
<!doctype html>
<html>
<head>
<?php require_once("inc/top.php");?>
<style>
	.align
	{
		text-align: center;
	}
	.mt
	{
		margin-top:50px;
	}
	.color
	{
		color: #38AFD3;
	}
</style>
</head>

<body>
<?php require_once("inc/header.php");?>
<div class="container-fluid my-fluid" >
	<div class="row">
		<?php require_once("inc/aside-bar.php");?>
		<div class="col-lg-9 leftm col-md-9  col-xs-12 " style="margin-top: 40px;">
			<div class="page-header">
			
  <h1>Deshboard <small>Subtext for header</small></h1>
</div>
	<ol class="breadcrumb">
  <li><a href="#"> <i class="fa fa-user" aria-hidden="true"></i> Profile</a></li>

</ol>
   
		<div class="row">
		<?php
	$select_user="SELECT * FROM `login`  WHERE Email = '$use'" ;
	     $login_run=mysqli_query($con,$select_user);
	if($user_row=mysqli_fetch_array($login_run))
	{

		$u_id=$user_row['Id'];
		$u_name=$user_row['name'];
		$u_email=$user_row['Email'];
		$u_image=$user_row['images'];
		$u_day=$user_row['dob'];
		
		$u_dis=$user_row['discripation'];
 	}
 	else
 	{
		header("location:Admin.php");
	}
 ?>
			<div class="col-md-12 align">
				<img  src="../images/<?php echo$u_image;?> " class="img-circle" width="200px;" height="200px;"/><br>
				<h2 align="center" class="color"><?php echo ucfirst($u_name);?></h2>
			</div>
		</div>
		<table class="table table-hover table-bordered mt">
			<thead>
				<tr align="center">
					<th>Date of borth</th>
					<th>Name</th>
					<th>Discripation</th>
					<th>Images</th>
				    <th>Edit</th>
					
				</tr>
			</thead>
			<tbody>
			
				<tr align="center">
					
					<td><?php echo $u_day;?></td>
					<td><?php echo ucfirst($u_name);?></td>
					<td><p align="justify"><?php echo ucfirst($u_dis);?></p></td>
					<td><img src="../images/<?php echo $u_image;?>" width="30px" height="30px" class="img-responsive"></td>
					
					
					<td><a href="edit-profile.php?upd=<?php echo $u_id;?> " name="pencil"><i class="fa fa-pencil"></i></a></td>
					
				</tr>
				
			</tbody>
		</table>
		<hr>
		</div>
		
			
		</div>
		
		</div>
		<?php require_once("inc/footer.php");?>
	
	

</body>
</html>
<?php
	}
else
{
	echo "<script>window.open('index.php','_self')</script>";
}
	?>