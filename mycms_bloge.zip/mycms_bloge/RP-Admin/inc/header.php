<style>
.margin
{
	padding-left: 30px;

}
.margi
{
	margin-top: -10px;
}
</style>
<div class="container-fluid bg-primary navbar navbar-fixed-top ">
<nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
          <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" >
                  <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="admin.php">
              <div class="col-xs-3 margi">
                  <?php 
                  $use_query="select * from login  WHERE Email = '$use'";
                  $use_run=mysqli_query($con,$use_query);
                  
				  	$use_row=mysqli_fetch_array($use_run);
				  	$use_image=$use_row['images'];
				
                  ?>
              <img src="../images/<?php echo $use_image; ?>" alt="logo" class="img-circle" width="40px;" height="40px;">
                            </div>
                            <div class="col-xs-9 margin ">
                            <?php
                            $select_users="SELECT * FROM `login`  WHERE Email = '$use'" ;
	     $login_runs=mysqli_query($con,$select_users);
	if($user_row=mysqli_fetch_array($login_runs))
	{

    $u_id=$user_row['Id'];
   $u_name=$user_row['name'];
    $u_image=$user_row['images'];
 }
 ?>
                            <?php echo ucfirst($u_name); ?>
                            </div>
                            
</a>
          </div>
          <div id="navbar" class="collapse navbar-collapse  ">
              <ul class="nav navbar-nav    pull-right"> 
			<li><a href="post.php"><i class="fa fa-plus" aria-hidden="true"></i> Add Post</a></li>
			<li><a href="user.php"><i class="fa fa-user-md"></i> Add User</a></li>
			<li><a href="Profile.php"><i class="fa fa-user" aria-hidden="true"></i> Profile</a></li>
			<li><a href="logout.php"><i class="fa fa-power-off" aria-hidden="true"></i> Logout</a></li>
			
		</ul>
          </div>
      </div>
  </nav>
</div>