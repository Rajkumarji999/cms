<div class="container-fluid footer">
		<div class="container">
		 <?php
                            $select_users="SELECT * FROM `login`  WHERE Email = '$use'" ;
	     $login_runs=mysqli_query($con,$select_users);
	if($user_row=mysqli_fetch_array($login_runs))
	{

    $u_id=$user_row['Id'];
   $u_name=$user_row['name'];
    $u_image=$user_row['images'];
 }
 ?>
<p>Copyright &copy; by <a href=""><?php echo ucfirst($u_name); ?></a> . All Right Reserved from 2019- <?php echo date('Y'); ?>.</p>
</div>
		</div>
	