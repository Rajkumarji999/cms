
<?php 
ob_start();
$use=$_SESSION['user'];
include('../connect.php');?>
<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" type="text/javascript" src="../js/jquery-3.3.1.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	 <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<title>Admin</title>
<script>
	$(document).ready(function(){
	$('#select_all').on('click',function(){
		if(this.checked){
			$('.checkbox').each(function(){
				this.checked=true;
			});
		}
		else
		{
			$('.checkbox').each(function(){
				this.checked=false;
			});
		}
	});
	$('.checkbox').on('click',function(){
		if($('.checkbox:checked').length==$('.checkbox').length){
			$('#select_all').prop('checked',true);
		}
		else
		{
			$('#select_all').prop('checked',false);
		}
	});
	});
</script>
