<div class="col-lg-3 navbar-fixed-right col-md-3 col-xs-12  " style="margin-top: 90px; color:white;">
			<div class="list-group" >
  <a href="Admin.php" class="list-group-item active"><i class="fa fa-tachometer" aria-hidden="true"></i>
  Deshboard
  </a>
  <?php 
					
					$v="select * FROM posts where status='publish'";
					$qu=mysqli_query($con,$v);
					$count=mysqli_num_rows($qu);
					
					?>
  <a href="post.php" class="list-group-item"><span class="badge"><?php echo $count; ?></span><i class="fa fa-reply-all" aria-hidden="true"></i> All post </a>
  <?php 
					
					$s="select * FROM comment where status='pending'";
					$q=mysqli_query($con,$s);
					$count=mysqli_num_rows($q);
					
					?>
					
				
  <a href="comment.php" class="list-group-item"><span class="badge"><?php echo $count; ?> </span><i class="fa fa-comment" aria-hidden="true"></i> Comment</a>
				<?php 
					$c_query="select * FROM categories";
					$c_run=mysqli_query($con,$c_query);
					$count=mysqli_num_rows($c_run);
					
						
					
					?>
					 
  <a href="categories.php" class="list-group-item"><span class="badge"><?php echo $count; ?></span> <i class="fa fa-users" aria-hidden="true"></i> categories </a>
  <?php 
					$s="select * FROM login";
					$q=mysqli_query($con,$s);
					$count=mysqli_num_rows($q);
					
					?>
  <a href="User.php" class="list-group-item"><span class="badge"><?php echo $count; ?></span><i class="fa fa-user" aria-hidden="true"></i> users</a>
</div>
		</div>