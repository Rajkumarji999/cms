<?php
session_start();
if(isset($_SESSION['user']))
{
	

?>
<!doctype html>
<html>
<head>
<?php require_once("inc/top.php"); ?>
</head>

<body>
<?php require_once("inc/header.php");?>
<div class="container-fluid my-fluid" >
	<div class="row">
		<?php require_once("inc/aside-bar.php");?>
		<form action="" method="post" enctype="multipart/form-data">
		<div class="col-lg-9 leftm col-md-9  col-xs-12 " style="margin-top: 40px;">
			<div class="page-header">
			
  <h1>Comment <small>Subtext for header</small></h1>
</div>
	<ol class="breadcrumb">
  <li><a href="#"> <i class="fa fa-comment" aria-hidden="true"></i> Comment</a></li>

</ol>
     	<div class="row">

	
	<div class="col-lg-12 col-md-12 col-xs-12">
	
		
			<div class="row">
		<div class="col-md-6 col-xs-12 col-lg-8 ">
		<div class="row">
				<div class="col-lg-4 ">
					<div class="form-group">	
						<select class="form-control" id=""  name="delete">
						<option >-Select-</option>
						<?php if(isset($_SESSION['user'])&& $_SESSION['role']== 'Administrater')
{
	?>
							<option value="delete">Delete</option>
							<option value="Pending">Change to Pending</option>
							<?php 
							}
								?>	
							
							<option value="approve">Change to Approve</option>
							
						</select>
					</div>
				</div>
				<div class="col-lg-8">
					<input type="submit" name="del" class="btn btn-success" value="Apply">
					
				</div>
					
			</div>
		</div>
	<div class="col-md-6 col-xs-12 col-lg-4">
   			<div class="input-group">
   					<input type="text" class="form-control"  name="serch" placeholder="search here.....">
   					<span class="input-group-btn">
   						<input type="submit" name="submit" class="btn btn-default" value="Go!">
   					</span>
   				</div>	
	
	</div>
	</div>
		<?php
				if(isset($_POST['del']))
				{
					
					$del= $_POST['delete'];
					if(isset($_POST['chek']))
					{
						$check =$_POST['chek'];
					for($i=0; $i<count($check); $i++)
					{
						 $c_id2 = $check[$i];	
						 if('delete'== $del)
						 {
						 	$del_qu="delete from comment where id='$c_id2'";
						 	$run_d=mysqli_query($con,$del_qu);
						 }
			             else if('approve'==$del ){
			             	
						 	$aq="UPDATE `comment` SET `status` = 'approve' WHERE `comment`.`id` = '$c_id2'";
				      $ar=mysqli_query($con,$aq);
						 }
						 else if('Pending'==$del)
						 {
						 	$pq="UPDATE `comment` SET `status` = 'Pending' WHERE `comment`.`id` = '$c_id2'";
				      $pr=mysqli_query($con,$pq);
						 }
					}
				}else
					{
						echo '<P style="color:red;">Please select row</P>';
					}
				
				}
				?>
				
	</div>
	
			</div>
		<hr>
		<?php 
			
			if(isset($_POST['sub']))
			{
				$cont=$_POST['serch'];
				$show_com_query="select * from comment WHERE ";
				$show_com_query .=" name like '%$cont%'";
			
			}
			else
			{
				$show_com_query="select * from comment order by id  DESC";
		
			}
	        $show_com_run=mysqli_query($con,$show_com_query);
	if(mysqli_num_rows($show_com_run) > 0)
	{
			?>
			<div class="table-responsive">
		<h3>New user</h3>
		<table class="table table-hover table-bordered ">
			<thead align="center">
			
			
				<tr>
				<th><input  type="checkbox" name="all" id="select_all"/></th>
					<th>Date</th>
					<th>Name</th>
					<th>Username</th>
					<th>Post id</th>
					<th>Email</th>
					<th>website</th>
					<th>images</th>
					<th>comments</th>
					<th>Status</th>
					
				</tr>
			</thead>
			<tbody align="center">
				
				<?php
			 while($show_com_row=mysqli_fetch_array($show_com_run))
				{
		        $show_com_id=$show_com_row['id'];	
				$show_com_date=getdate($show_com_row['date']);
				$show_com_day=$show_com_date['mday'];
				$show_com_month=$show_com_date['month'];
				$show_com_year=$show_com_date['year'];
				$show_com_name=$show_com_row['name'];
				$show_com_user=$show_com_row['Username'];
				$show_com_web=$show_com_row['Website'];
				$show_com_img=$show_com_row['image'];
				$show_com_com=$show_com_row['comments'];
				$show_com_status=$show_com_row['status'];
				$show_com_post_id=$show_com_row['post_id'];
				$show_com_email=$show_com_row['email'];
				?>
				<tr>
				<td><input  type="checkbox" name="chek[]" class="checkbox" value="<?php echo $show_com_id; ?>"/></td>
				
					<td><?php  echo $show_com_day; ?>-<?php  echo $show_com_month; ?>-<?php  echo $show_com_year; ?></td>
					<td><?php  echo $show_com_name; ?></td>
					<td><?php  echo $show_com_user; ?></td>
					<td><?php  echo $show_com_post_id; ?></td>
					<td><?php  echo $show_com_email; ?></td>
					<td><a href="<?php echo$show_com_web;?>" target="_blank"> <?php  echo $show_com_web; ?></a></td>
					<td><img src="../image/<?php  echo $show_com_img; ?>" height="50px;" width="50px;"></td>
					<td><?php  echo $show_com_com; ?></td>
					<?php
					
					if(isset($_GET['upd1']))
					{  
					
				
					   $upd1=$_GET['upd1'];
						$q="UPDATE `comment` SET `status` = 'approve' WHERE `comment`.`id` = '$upd1'";
				     $r=mysqli_query($con,$q); 
				     
					?>
				
					<td><a href="comment.php?upd1=<?php  echo $show_com_id ; ?>" class="btn btn-success"><?php  echo ucfirst($show_com_status); ?></a></td>
			<?php }
			else {
				
				?>
				<td><a href="comment.php?upd1=<?php  echo $show_com_id ; ?>" class="btn btn-success"><?php  echo ucfirst($show_com_status); ?></a></td>
				<?php
			}
			 ?>		
				
						
				</tr>
				<?php } ?>
			</tbody>
		</table>
		</div>
		<?php } else
		{
			echo"<h2 style='color:red; text-align:center; margin-top:140px; margin-bottom:140px;'>Sorry no data yet !</h2>";
		}?>
	
		<hr>
		</div>
		</form>
				
		</div>
		
		</div>
		<?php require_once("inc/footer.php");?>
	
	

</body>
</html>
<?php
	}
else
{
	echo "<script>window.open('index.php','_self')</script>";
}
	?>