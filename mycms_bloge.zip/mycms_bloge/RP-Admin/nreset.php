<?php session_start();
 $ses=$_SESSION['user'];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>reset</title>
<link rel="stylesheet" type="text/css" href="../style.css"> 
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" href="js/bootstrap-3.3.7.js">
<style>
	.container
	{
		width: 30%;
		border: 1px solid gray;
		background:#505050 ;
	}
	
	</style>
</head>

<body>
<div class="container imgx" style="margin-top: 20px;">
<div class="ml-3">
	<h3 class="text-center text-white">Reset password...</h3>
</div>
<div class="ml-4">
<?php	
	include('../connect.php');
	
	
	if(isset($_POST['reset']))
	{
	$fna=$_POST['pass1'];
	$fn=$_POST['pass2'];
	
		if($fna==$fn)
		{
			$v="UPDATE `login` SET ` `password` = '$fna' WHERE `login`UPDATE `login` SET `password` = '$fna' WHERE `login`.`Email` = '$ses'";
		$run1=mysqli_query($con,$v);
		if($run1)
		{
			header('location:login.php');
		}
		}
		else{
			echo "<script>alert('Enter the same password')</script>";
		}
	}
	?>
<form action="" method="POST">

		<input type="password" class="form-control" name="pass1" placeholder="Enter The new pasword">
		<br>
		<input type="password" class="form-control" name="pass2" placeholder="Enter The Repassword">
		<br>
		<label>
		<input type="submit" class="btn btn-primary" name="reset" value="Reset now">
		</label>
	</form>
	</div>
	</div>
</body>
</html>