<?php 
include('connect.php');

$de= $_GET['com_id'];
$s="DELETE FROM `comment` WHERE `id` = '$de'";
if(isset($_SESSION['user'])&& $_SESSION['role']== 'Administrater')
{
$run=mysqli_query($con,$s);
if($run)
{
	echo "<script>window.location='comment.php';</script>";
}
else
{
	echo "error";
}
}
else
{
	header('location:Admin.php');
}
?>