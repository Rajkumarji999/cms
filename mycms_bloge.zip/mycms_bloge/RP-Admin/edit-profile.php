<?php 
session_start();
 include('connect.php');
?>
<!doctype html>
<html>
<head>
<?php 
require_once("inc/top.php");
?>
<title>Edit User</title>
<style>
	.navbar-default li a
	{
		color: #fff;
	}
	.navbar-default li a:hover
	{
		background-color:red;
	}
	</style>
</head>

<body>

<?php require_once("inc/header.php"); ?>
<div class="container-fluid ">
	<div class="row">
		<?php require_once("inc/aside-bar.php"); ?>
		<div class="col-lg-9 leftm" style="margin-top: 40px;">
			<div class="page-header">
  <h1>User <small>Subtext for header</small></h1>
</div>
	<ol class="breadcrumb">
		<li><a href="#"> <i class="fa fa-user" aria-hidden="true"></i> User</a></li>

</ol>

<div class="row cont">
<?php
  $use=$_SESSION['user'];
  $ed=$_GET['upd'];
$s="SELECT * FROM `login` where Id ='$ed'";
$run=mysqli_query($con,$s);
while($row=mysqli_fetch_array($run))
{$Email=$row['Email'];
	if($Email==$use)
	{
		
	$id=$row['Id'];
	$name=$row['name'];
	$pass=$row['password'];
	$images=$row['images'];
	$day=$row['dob'];
$dic=$row['discripation'];
}
else
{
	echo "<script>window.location='index.php';</script>";
}
}
?>
		
	<div class="col-lg-12 ">
	<div  style="color:#ffff ; background-color: #ea6a15;">
	<h2 class="text-center text-bold">Edit Our Profile</h2>
	</div>
	<div style="margin-top: 20px;">
		<form action="" method="post" enctype="multipart/form-data">
			<div class="form-group">
			<label>Name</label>
				<input  type="text" name="name" class="form-control" required="" value="<?php echo $name; ?>" placeholder="Enter name"/>
			</div>
			<div class="form-group">
			<label>Date of borth </label>
			<input  type="date" value="<?php echo $day ;?>" name="dobu"  class="form-control">
			</div>
			<div class="form-group">
			<label>Password</label>
				<input  type="password" name="pass"class="form-control" required=""  value="<?php echo $pass; ?>" placeholder="Enter Password"/>
			</div>
			<div class="form-group">
			<label>Re-Password</label>
				<input  type="password" name="rpass"class="form-control" required="" value="<?php echo $pass; ?>"  placeholder="Enter Password"/>    
				
			</div>
			
			<div class="form-group">
			<label>Image</label>
				<input  type="file" name="file" class="form-control" />
				<img  src="../images/<?php  echo $images;?>" width="50px;" height="50px;"/>
			</div>
			
			<div class="form-group">
			<label>Discripation</label>
				<textarea type="text" name="dic" rows="20" cols="20" class="form-control textme"><?php echo $dic; ?></textarea>
			</div>
			<div class="form-group">
				<input  type="submit" name="sub" value="Edit-profile" class="btn btn-primary" />
			</div>
		</form>
		</div>
		<?php 
		   

		if(isset($_POST['sub']))
		{
			
			$name= $_POST['name'];
	         $dob= $_POST['dobu'];

	         $pass= $_POST['pass'];
	          $rpass= $_POST['rpass'];
	         $dic= $_POST['dic'];
	         $date=time();
	        $file = $_FILES['file']['name'];
         $file_loc = $_FILES['file']['tmp_name'];
           $file_size = $_FILES['file']['size'];
          $file_type = $_FILES['file']['type'];
			 if($file=='')
			 {
			 	$u="UPDATE `login` SET `name` = '$name', `password` = '$pass',  `update_date` = '$date',`dob` = '$dob', `discripation` = ' $dic ' WHERE `login`.`Id` = '$ed'
";
$run=mysqli_query($con,$u) ;
	
	if($run)
	{
		 
    header('Location:index.php');
      	
	}
	else
	{
		echo "error";
	}	
	
			 }else
			 {
			 $u="UPDATE `login` SET `name` = '$name', `password` = '$pass', `images` = '$file', `update_date` = '$date',`dob` = '$dob', `discripation` = ' $dic ' WHERE `login`.`Id` = '$ed'
";
	$run=mysqli_query($con,$u) ;
	
	if($run)
	{ 
	session_destroy();
    header('Location:index.php');
      	
	}
	else
	{
		echo "error";
	}	
			 }
			
		}
		?>
  </div>
  </div>
</body>
</html>