<?php 
session_start();
include('connect.php');

$de= $_GET['de'];

if(isset($_SESSION['user'])&& $_SESSION['role'] == 'Administrater')
{
	$s="DELETE FROM `posts` WHERE `id` = '$de'";
	$run=mysqli_query($con,$s);
if($run)
{
	echo "<script>window.location='post.php';</script>";
}
else
{
	echo "error";
}

}
else
{
	header('location:Admin.php');
	
}
?>