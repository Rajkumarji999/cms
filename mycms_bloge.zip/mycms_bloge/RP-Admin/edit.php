<?php
session_start();
$use=$_SESSION['user'];
if(isset($use))
{
	

?>
<!doctype html>
<html>
<head>
<?php 
require_once("inc/top.php");
?>
<style>
	.textme
	{
		resize: none;
	}
</style>
</head>

<body>
<?php require_once("inc/header.php"); ?>
<div class="container-fluid my-fluid " >
	<div class="row">
		<?php require_once("inc/aside-bar.php"); ?>
		<div class="col-lg-9 leftm col-md-9  col-xs-12 " style="margin-top: 40px;">
			<div class="page-header">
			
  <h1>Deshboard <small>Subtext for header</small></h1>
</div>
	<ol class="breadcrumb">
  <li><a href="Admin.php"> <i class="fa fa-tachometer" aria-hidden="true"></i> Deshboard</a></li>

</ol>
     
		<hr>
				<div class="col-lg-12 ">
	<div  style="color:#ffff ; background-color: #ea6a15;">
	<h2 class="text-center text-bold">Update posts </h2>
	</div>
	
	<div style="margin-top: 20px;">
	<?php 
	$ed=$_GET['upd'];
	if(isset($_POST['submitup']))
	{ 
		 $title=$_POST['title'];
		 $tag=$_POST['tags'];
		 $categories=$_POST['selectbox'];
		 $status=$_POST['statubox'];
		$post=$_POST['textarea'];
		$date=time();
		$file = $_FILES['file']['name'];
        $file_loc = $_FILES['file']['tmp_name'];
        $file_size = $_FILES['file']['size'];
        $file_type = $_FILES['file']['type'];
        move_uploaded_file($_FILES["file"]["tmp_name"],"../images/$file");
        if($file=='')
        {
		$up_query="UPDATE `posts` SET `title` = '$title', `tags` = '$tag',  `categories` = '$categories', `status` = '$status', `post_update_date` = '$date',`post_data` = '$post' WHERE `id` = '$ed' ";	
		if(mysqli_query($con,$up_query))
	{
		header('location:post.php');
	}
	else
	{
		$error_sms="oh ! no your data is not update ";
	}
		}else{
			$up_query="UPDATE `posts` SET `title` = '$title', `tags` = '$tag', `image` = '$file', `categories` = '$categories', `status` = '$status', `post_update_date` = '$date',`post_data` = '$post' WHERE `id` = '$ed' ";
 	if(mysqli_query($con,$up_query))
	{
		header('location:post.php');
	}
	else
	{
		$error_sms="oh ! no your data is not update ";
	}
	}
 }
	
   	$show_up_query="select * from posts  where id='$ed'";
	$show_up_run=mysqli_query($con,$show_up_query);
	
	$show_row=mysqli_fetch_array($show_up_run);
				
		        $show_id=$show_row['id'];	
				$show_title=$show_row['title'];
				$show_image=$show_row['image'];
				$show_categories=$show_row['categories'];
				$show_tags=$show_row['tags'];
				$show_data=$show_row['post_data'];
				$show_views=$show_row['views'];
				$show_status=$show_row['status'];

	?>
	<?php if(isset($msg)){
		
		?>
		<div class="alert alert-danger" role="alert"><?php   echo $error_sms; ?></div>
	
	<?php } ?>
		<form action="" method="post" enctype="multipart/form-data">
			<div class="form-group">
			<label>Title</label>
				<input  type="text" name="title"class="form-control"  value="<?php echo $show_title;?> " required=""  placeholder="Enter Title"/>
			</div>
			<div class="form-group">
			<label>Tags</label>
				<input  type="text" name="tags" class="form-control" required="" value="<?php echo $show_tags;?> " placeholder="Enter Tags" />
			</div>
			<div class="form-group">
			<label>Image</label>
				<input  type="file" name="file" class="form-control"  />
				<img  src="../images/<?php  echo $show_image;?>" width="50px;" height="50px;"/>
			</div>
			<div class="form-group">
			<label>Categories</label>
				<select name="selectbox" class="form-control" required >
              <option>choose the Categories</option>
               
                 <option value="<?php echo ucfirst($show_categories); ?> " <?php 
                 if($show_categories==$show_categories)
					{
						echo "selected";
					}
                 ?>
              ><?php echo ucfirst($show_categories); ?></option>
            </select>
			</div>
			<div class="form-group">
			<label>Status</label>
				<select name="statubox" class="form-control" required >
              <option>choose the Status</option>
              <?php if(isset($_SESSION['user']) && $_SESSION['role'] == 'Administrater') {
			  	
			 ?>
                 <option value="Publish" <?php if($show_status=="Publish")
					{
						echo "selected";
					}
                 ?>>Publish</option>
                 <?php  } ?>
				  <option value="Drop"
				  <?php if($show_status=="Drop")
					{
						echo "selected";
					}?>>Drop</option>
            </select>
			</div>
			<div class="form-group">
			<label>Post data</label>
				<textarea name="textarea" class="form-control textme" id="taxtarea"rows="20" cols="20">
					<?php echo ucfirst($show_data);?>
				</textarea>
			</div>
			
			<div class="form-group">
				<input  type="submit" name="submitup" value="Update Post" class="btn btn-primary" />
			</div>
		</form>
		</div>
			</div>
		</div>
		
			
		</div>
		
		</div>


		
	
		<?php require_once("inc/footer.php");  ?>
	<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
  

</body>
</html>
<?php
	}
else
{
	echo "<script>window.open('index.php','_self')</script>";
}
	?>