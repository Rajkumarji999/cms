<?php 
session_start();
$page="edit1.php";

if(isset($_SESSION['user'])&& isset($page)  && $_SESSION['role'] == 'local')

{
	header('location:Admin.php');
}
?>
<!doctype html>
<html>
<head>
<?php 
require_once("inc/top.php");
?>
<title>Edit User</title>
<style>
	.navbar-default li a
	{
		color: #fff;
	}
	.navbar-default li a:hover
	{
		background-color:red;
	}
	</style>
</head>

<body>

<?php require_once("inc/header.php"); ?>
<div class="container-fluid ">
	<div class="row">
		<?php require_once("inc/aside-bar.php"); ?>
		<div class="col-lg-9 leftm" style="margin-top: 40px;">
			<div class="page-header">
  <h1>User <small>Subtext for header</small></h1>
</div>
	<ol class="breadcrumb">
		<li><a href="#"> <i class="fa fa-user" aria-hidden="true"></i> User</a></li>

</ol>

<div class="row cont">
<?php
  include("connect.php");
  $ed=$_GET['upd'];
$s="SELECT * FROM `login` where Id ='$ed'";
$run=mysqli_query($con,$s);
while($row=mysqli_fetch_array($run))
{
	$id=$row['Id'];
	$name=$row['name'];
	$pass=$row['password'];
	$role=$row['role'];
	$Email=$row['Email'];
	$images=$row['images'];
	$day=$row['dob'];
$dic=$row['discripation'];
}
?>
		
	<div class="col-lg-12 ">
	<div  style="color:#ffff ; background-color: #ea6a15;">
	<h2 class="text-center text-bold">Update User</h2>
	</div>
	<div style="margin-top: 20px;">
		<form action="" method="post" enctype="multipart/form-data">
			<div class="form-group">
			<label>Name</label>
				<input  type="text" name="name" class="form-control" required="" value="<?php echo $name; ?>" placeholder="Enter name"/>
			</div>
			<div class="form-group">
			<label>Date of borth </label>
			<input  type="date" value="<?php echo $day ;?>" name="dobu"  class="form-control">
			</div>
			<div class="form-group">
			<label>Password</label>
				<input  type="password" name="pass"class="form-control" required=""  value="<?php echo $pass; ?>" placeholder="Enter Password"/>
			</div>
			<div class="form-group">
			<label>Re-Password</label>
				<input  type="password" name="rpass"class="form-control" required="" value="<?php echo $pass; ?>"  placeholder="Enter Password"/>    
				
			</div>
			<div class="form-group">
			<label>Email</label>
				<input  type="email" name="email" class="form-control" value="<?php echo $Email;?>" required=""  placeholder="Enter Email" />
			</div>
			<div class="form-group">
			<label>Image</label>
				<input  type="file" name="file" class="form-control" />
				<img  src="../images/<?php  echo $images;?>" width="50px;" height="50px;"/>
			</div>
			<div class="form-group">
			<label>Role</label>
				<select name="role" class="form-control" required >
              <option>choose the Role</option>
            
                 <option value="Administrater"  <?php if($role=="Administrater")
					{
						echo "selected";
					}
                 ?>>Administrater</option>
				  <option value="local"  <?php if($role=="local")
					{
						echo "selected";
					}
                 ?>>local</option>
            </select>
			</div>
			<div class="form-group">
			<label>Discripation</label>
				<textarea type="text" name="dic" rows="20" cols="20" class="form-control textme"><?php echo $dic; ?></textarea>
			</div>
			<div class="form-group">
				<input  type="submit" name="sub" value="Update User" class="btn btn-primary" />
			</div>
		</form>
		</div>
		<?php 
		    include('connect.php');
		    
		if(isset($_POST['sub']))
		{
			$rol= $_POST['role'];
			$name= $_POST['name'];
	         $dob= $_POST['dobu'];
	         
	         $pass= $_POST['pass'];
	          $rpass= $_POST['rpass'];
	         $email= $_POST['email'];
	         $dic= $_POST['dic'];
	         $date=time();
	        $file = $_FILES['file']['name'];
         $file_loc = $_FILES['file']['tmp_name'];
           $file_size = $_FILES['file']['size'];
          $file_type = $_FILES['file']['type'];
			move_uploaded_file($_FILES["file"]["tmp_name"],"../images/$file");
			if($file=='')
			{
			$u="UPDATE `login` SET `Email` = '$email', `name` = '$name', `password` = '$pass', `role` = '$rol', `dob` = '$dob', `discripation` = ' $dic ', update_date='$date' WHERE `login`.`Id` = '$ed'
";	
$run=mysqli_query($con,$u) ;
	if($run)
	{
		if($use=='Administrater')
		{
			
		
		session_destroy();
       echo '<script>window.location="index.php";</script>';}else
        {
        	echo '<script>window.location="User.php";</script>';
		
		}
	}
	else
	{
		echo "error";
	}	
			
			
}
else
			{
			$u="UPDATE `login` SET `Email` = '$email', `name` = '$name', `password` = '$pass', `images` = '$file', `role` = '$rol', `dob` = '$dob', `discripation` = ' $dic ', update_date='$date' WHERE `login`.`Id` = '$ed'
";
if(isset($_SESSION['user'])&& $_SESSION['role']== 'Administrater')
{
	$run=mysqli_query($con,$u) ;
	if($run)
	{
		if($Email==$use)
		{
			
		
		session_destroy();
        header('Location:index.php');}
        else
        {
        	echo '<script>window.location="User.php";</script>';
		
		}
	}
	else
	{
		echo "error";
	}	
			
			
}
else
{
	echo '<script>window.location="Admin.php";</script>';
}
		}}
		?>
  </div>
  </div>
</body>
</html>