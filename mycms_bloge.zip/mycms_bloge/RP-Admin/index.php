
<?php
session_start();
if(isset($_SESSION['user']))
{
	
	echo "<script>window.open('Admin.php','_self')</script>";	
}
else
{
	


?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>login page</title>
<link rel="stylesheet" type="text/css" href="../style.css"> 
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" href="js/bootstrap-3.3.7.js">
<style>
	.container{
		width: 30%;
		border: 1px solid gray;
	    background:#505050;
	    margin-top: 150px;
	}
	.ML
	{
	
	margin-left: 150px;
	}
	@media(max-width:876px)
	{
	.container{
		width: 90%;
		border: 1px solid gray;
	    background:#505050;
	    margin-top: 150px;
	}
	
	}
	@media(max-width:900px)
	{
	.container{
		width: 90%;
		border: 1px solid gray;
	    background:#505050;
	    margin-top: 150px;
	}
	
	}
	</style>
</head>

<body>

<div class="container imgx ">
<div class="row">
<div class="col-lg-12 col-md-12 col-xl-12 col-xs-12">
<div class="mt-2">
	<h3 class="text-center text-white">Login Here...</h3>
</div>
<div class="mt-3">
<?php
	
include("../connect.php");
if(isset($_POST["login"]))
{   
   
	$nam=mysqli_real_escape_string($con,$_POST["name"]);
	$pass=mysqli_real_escape_string($con,$_POST["pass"]);
	$s="select * from login where  
	 Email='$nam' && password='$pass'";
	 $run=mysqli_query($con,$s);
	 if(mysqli_num_rows($run)>0)
	 {
		$res=mysqli_fetch_array($run);
		$db_email=$res['Email'];
		$db_pass=$res['password'];
		$db_role=$res['role'];
	 	$password=crypt($pass,$db_email);
	 	if($nam==$db_email && $pass==$db_pass)
	 	{
		    echo"<script>window.location='admin.php';</script>";
			$_SESSION['user']=$db_email;
			$_SESSION['role']=$db_role;
		}
	   else
	   {
	   	$msg="<p style='color:red'>Your Email And Password Is Incorrect !</p>";
	   }
	 
	     	
	 }
	 else
	 {
        $msg="<p style='color:red'>Your Email And Password Is Incorrect !</p>";
	 }
	  
}
if(isset($msg))
{
	echo $msg;
}
?>

	<form action="" method="POST">

		<input type="text" class="form-control" name="name" placeholder="Enter The Email" required="">
		<br>
		<input type="password" class="form-control" name="pass" placeholder="Enter The password" required="">
		<br>
		<label>
		<input type="submit" class="btn btn-primary" name="login" value="login">
		<label class="pull-right ML">
		<a href="reset.php" class="text-white">lost your password?</a>
		</label>
		</label>
	</form>
</div>
</div> 
</div>
</div>

</body>
</html>
<?php
	}
	?>