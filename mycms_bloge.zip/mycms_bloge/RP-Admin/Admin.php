<?php
session_start();
include("connect.php");
if(isset($_SESSION['user']))
{
	

?>
<!doctype html>
<html>
<head>
<?php 
require_once("inc/top.php");
?>

</head>

<body>
<?php require_once("inc/header.php"); ?>
<div class="container-fluid my-fluid " >
	<div class="row">
		<?php require_once("inc/aside-bar.php"); ?>
		<form action=""method="post" enctype="multipart/form-data">
		<div class="col-lg-9 leftm col-md-9  col-xs-12 " style="margin-top: 40px;">
			<div class="page-header">
			
  <h1>Deshboard <small>Subtext for header</small></h1>
</div>
	<ol class="breadcrumb">
  <li><a href="Admin.php"> <i class="fa fa-tachometer" aria-hidden="true"></i> Deshboard</a></li>

</ol>
     <div class="row tag-boxes heddin2">
			<div class="col-lg-3 col-md-3 col-xs-12 ">
				<div class="panel panel-primary">
				<div class="panel-heading">
				<div class="row">
				<div class="col-lg-3 col-md-3 col-xs-12 ">
					<i class="fa fa-comments fa-5x" aria-hidden="true"></i>
					</div>
					<div class="col-lg-9 col-md-9 col-xs-12 ">
					<?php 
				
					$s="select * FROM comment where status='pending'";
					$q=mysqli_query($con,$s);
					$count=mysqli_num_rows($q);
					
					?>
						<div class="text-right fot"><?php echo $count; ?> </div>
						<div class="text-right ">New comments</div>
					</div>
					</div>
				</div>
				<a href="comment.php">
						<div class="panel-footer">
						<span class="pull-left">VIEW ALL COMMENTS</span>
						<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
						<div class="clearfix"></div>
					</div>
					</a>
			</div>
			
		</div>
		<div class="col-lg-3 col-md-3 col-xs-12 ">
				<div class="panel " style="background-color: red; color:white;">
				<div class="panel-heading">
				<div class="row">
				<div class="col-lg-3 col-md-3 col-xs-12 ">
					<i class="fa fa-reply-all fa-5x" aria-hidden="true"></i>
					</div>
					<div class="col-lg-9 col-md-9 col-xs-12 ">
					<?php 
					
					$v="select * FROM posts  where status='publish'";
					$qu=mysqli_query($con,$v);
					$count=mysqli_num_rows($qu);
					
					?>
						<div class="text-right fot"><?php echo $count; ?></div>
						<div class="text-right ">New post</div>
					</div>
					</div>
				</div>
				<a href="post.php">
				<div class="panel-footer">
						<span class="pull-left">VIEW ALL POST</span>
						<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
						<div class="clearfix"></div>
					</div>
					</a>
			</div>
			
		</div>
		<div class="col-lg-3 col-md-3 col-xs-12 ">
				<div class="panel "  style="background-color:#F39C12; color:white;">
				<div class="panel-heading">
				<div class="row">
				<div class="col-lg-3 col-md-3 col-xs-12 ">
					 <i class="fa fa-users fa-5x" aria-hidden="true"></i>
					</div>
					<div class="col-lg-9 col-md-9 col-xs-12 ">
						<?php 
					$c_query="select * FROM categories";
					$c_run=mysqli_query($con,$c_query);
					$count=mysqli_num_rows($c_run);
					
					?>
						<div class="text-right fot"><?php echo $count; ?> </div>
						<div class="text-right ">Categories</div>
					</div>
					</div>
				</div>
				<a href="categories.php">
				<div class="panel-footer">
						<span class="pull-left">VIEW ALL CATEGORIES</span>
						<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
						<div class="clearfix"></div>
					</div>
					</a>
			</div>
			
		</div>
		<div class="col-lg-3 col-md-3 col-xs-12 ">
				<div class="panel " style="background-color: #00A65A; color:white;">
				<div class="panel-heading">
				<div class="row">
				<div class="col-lg-3 col-md-3 col-xs-12 ">
					<i class="fa fa-user fa-5x" aria-hidden="true"></i>
					</div>
					<div class="col-lg-9 col-md-9 col-xs-12 ">
					<?php 
					
					$s="select * FROM login";
					$q=mysqli_query($con,$s);
					$count=mysqli_num_rows($q);
			        $ushow=mysqli_fetch_array($q);
						$re=$ushow['role'];
					
					?>
						<div class="text-right fot"><?php echo $count; ?></div>
						<div class="text-right ">New USER</div>
					</div>
					</div>
				</div>
			
				
				<a href="User.php">
				<div class="panel-footer">
						<span class="pull-left">VIEW ALL USER</span>
						<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
						<div class="clearfix"></div>
					</div>
					</a>
					
					
					
			</div>
			
		</div>
			
		</div>
		   <div class="row tag-boxes heddin1">
			<div class="col-lg-3 col-md-3 col-xs-12 ">
				<div class="panel panel-primary">
				<div class="panel-heading">
				<div class="row">
				<div class="col-lg-3 col-md-3 col-xs-12 ">
					<i class="fa fa-comments fa-5x" aria-hidden="true"></i>
					</div>
					<div class="col-lg-9 col-md-9 col-xs-12 ">
					<?php 
				
					$s="select * FROM comment where status='pending'";
					$q=mysqli_query($con,$s);
					$count=mysqli_num_rows($q);
					
					?>
						<div class="text-right fot"><?php echo $count; ?> </div>
						<div class="text-right ">New comments</div>
					</div>
					</div>
				</div>
				<a href="comment.php">
						<div class="panel-footer">
						<span class="pull-left">VIEW ALL <br>COMMENTS</span>
						<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
						<div class="clearfix"></div>
					</div>
					</a>
			</div>
			
		</div>
		<div class="col-lg-3 col-md-3 col-xs-12 ">
				<div class="panel " style="background-color: red; color:white;">
				<div class="panel-heading">
				<div class="row">
				<div class="col-lg-3 col-md-3 col-xs-12 ">
					<i class="fa fa-reply-all fa-5x" aria-hidden="true"></i>
					</div>
					<div class="col-lg-9 col-md-9 col-xs-12 ">
					<?php 
					
					$v="select * FROM posts  where status='publish'";
					$qu=mysqli_query($con,$v);
					$count=mysqli_num_rows($qu);
					
					?>
						<div class="text-right fot"><?php echo $count; ?></div>
						<div class="text-right ">New post</div>
					</div>
					</div>
				</div>
				<a href="post.php">
				<div class="panel-footer">
						<span class="pull-left">VIEW ALL<br> POST</span>
						<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
						<div class="clearfix"></div>
					</div>
					</a>
			</div>
			
		</div>
		<div class="col-lg-3 col-md-3 col-xs-12 ">
				<div class="panel "  style="background-color:#F39C12; color:white;">
				<div class="panel-heading">
				<div class="row">
				<div class="col-lg-3 col-md-3 col-xs-12 ">
					 <i class="fa fa-users fa-5x" aria-hidden="true"></i>
					</div>
					<div class="col-lg-9 col-md-9 col-xs-12 ">
						<?php 
					$c_query="select * FROM categories";
					$c_run=mysqli_query($con,$c_query);
					$count=mysqli_num_rows($c_run);
					
					?>
						<div class="text-right fot"><?php echo $count; ?> </div>
						<div class="text-right">Categories</div>
					</div>
					</div>
				</div>
				<a href="categories.php">
				<div class="panel-footer">
						<span class="pull-left">VIEW ALL <br>CATEGORIES</span>
						<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
						<div class="clearfix"></div>
					</div>
					</a>
			</div>
			
		</div>
		<div class="col-lg-3 col-md-3 col-xs-12 ">
				<div class="panel " style="background-color: #00A65A; color:white;">
				<div class="panel-heading">
				<div class="row">
				<div class="col-lg-3 col-md-3 col-xs-12 ">
					<i class="fa fa-user fa-5x" aria-hidden="true"></i>
					</div>
					<div class="col-lg-9 col-md-9 col-xs-12 ">
					<?php 
					
					$s="select * FROM login";
					$q=mysqli_query($con,$s);
					$count=mysqli_num_rows($q);
			        $ushow=mysqli_fetch_array($q);
						$re=$ushow['role'];
					
					?>
						<div class="text-right fot"><?php echo $count; ?></div>
						<div class="text-right ">New USER</div>
					</div>
					</div>
				</div>
			
				
				<a href="User.php">
				<div class="panel-footer">
						<span class="pull-left">VIEW ALL<br> USER</span>
						<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
						<div class="clearfix"></div>
					</div>
					</a>
					
					
					
			</div>
			
		</div>
			
		</div>
		<hr>
			<?php 
			if(isset($_POST['user'])) 
			{
	             $user_query="select * FROM login ";
				 } else if(isset($_POST['minimizeuser'])){
				 	 $user_query="select * FROM login  LIMIT 4";
				 }
				 else
				 {
				 	  $user_query="select * FROM login  LIMIT 4";
				 }
			
					$user_run=mysqli_query($con,$user_query);
					if(mysqli_num_rows($user_run)>0)
					{
						
	             ?>
			
		<h3>New user</h3>
		<div class="table-responsive">
		<table class="table table-hover">
			<thead>
				<tr>
					<th>Date</th>
					<th>Name</th>
					<th>Email</th>
					<th>Role</th>
				</tr>
			</thead>
			<tbody>
				<?php 
					while($user_fetch=mysqli_fetch_array($user_run))
					{ 
						$user_id=$user_fetch['Id'];
						$user_name=$user_fetch['name'];
						$user_email=$user_fetch['Email'];
						$user_role=$user_fetch['role'];
						date_default_timezone_set('Asia/Kolkata'); 
						$user_date=getdate($user_fetch['date']);
						$user_day=$user_date['mday'];
						$user_month=$user_date['month'];
						$user_year=$user_date['year'];
				?>
				<tr>
					<td><?php echo $user_day ; ?>-<?php echo $user_month ; ?>-<?php echo $user_year ; ?></td>
					<td><?php echo $user_name ; ?></td>
					<td><?php echo $user_email ; ?></td>
					<?php if($user_role=='Administrater') {?>
					<td style="color: green;"><?php echo $user_role ; ?></td>
					<?php } else
					{
						?>
						<td style="color: #1a1fe6;"><?php echo $user_role ; ?></td>
						<?php } ?>
				</tr>
				<?php } ?>
			</tbody>
		</table>
		<input type="submit" name="user"  value="view all user" class="btn btn-primary" >
		<input type="submit" name="minimizeuser"  value="minimize user" class="btn btn-primary" >
			<?php } ?>
			<?php if(isset($_POST['post'])) 
			{
	              $post_query="select * FROM posts";
				 } else if(isset($_POST['minimize'])){
				 	 $post_query="select * FROM posts LIMIT 4";
				 }
				 else
				 {
				 	 $post_query="select * FROM posts LIMIT 4";
				 }
			
					$post_run=mysqli_query($con,$post_query);
					if(mysqli_num_rows($post_run)>0)
					{
			?>
		<h3>New Post</h3>
		<div class="table-responsive">
		<table class="table table-hover">
			<thead>
				<tr>
					<th>Date</th>
					<th>Post title</th>
					<th>Category</th>
					<th>Views</th>
					
				</tr>
			</thead>
			<tbody>
			</div>
				<?php 
					while($post_fetch=mysqli_fetch_array($post_run))
					{ 
						$post_id=$post_fetch['id'];
						$post_title=$post_fetch['title'];
						$post_categories=$post_fetch['categories'];
						$post_views=$post_fetch['views'];
						$post_date=getdate($post_fetch['date']);
						$post_day=$post_date['mday'];
						$post_month=$post_date['month'];
						$post_year=$post_date['year'];
				?>
				<tr>
					<td><?php echo $post_day; ?>-<?php echo $post_month; ?>-<?php echo $post_year; ?></td>
					<td><?php echo $post_title; ?></td>
					<td><?php echo $post_categories; ?></td>
					<td><i class="fa fa-eye"></i><?php echo $post_views; ?></td>
				</tr>
				<?php } ?>
			</tbody>
		</table>
		
		</div>
		<input type="submit" name="post" class="btn btn-primary" value="view all Posts">
		<input type="submit" name="minimize" class="btn btn-primary" value="minimize Posts">
			<?php } ?>
		<hr>
		</div>
		
			
		</div>
	
		</div>
			</form>
	
		<?php require_once("inc/footer.php");  ?>
	

</body>
</html>
<?php
	}
else
{
	echo "<script>window.open('index.php','_self')</script>";
}
	?>