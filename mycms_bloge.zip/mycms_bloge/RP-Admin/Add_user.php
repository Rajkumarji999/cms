<?php 
session_start();
$url="Add_user.php";
if(isset($_SESSION['user'])&& isset($url)  && $_SESSION['role'] == 'local')
{
	header('location:Admin.php');
}
else if(isset($_SESSION['user']))
{
?>
<!doctype html>
<html>
<head>
<?php include_once("inc/top.php");?>
<style>
.textme
	{
		resize: none;
	}
	</style>
</head>

<body>

<?php include_once("inc/header.php");?>
<div class="container-fluid ">
	<div class="row">
		<?php include_once("inc/aside-bar.php");?>
		<div class="col-lg-9 col-md-9 col-xs-12	 leftm" style="margin-top: 40px;">
			<div class="page-header">
  <h1>User <small>Subtext for header</small></h1>
</div>
	<ol class="breadcrumb">
		<li><a href="#"> <i class="fa fa-user" aria-hidden="true"></i> User</a></li>

</ol>

<div class="row cont">
<?php 
		    include('../connect.php');
		if(isset($_POST['submit']))
		{
			$rol= $_POST['role'];
			$name= $_POST['name'];
	         $dob= $_POST['dob'];
	          
	         $pass= $_POST['pass'];
	          $rpass= $_POST['rpass'];
	         $email= $_POST['email'];
	         $dic= $_POST['dic'];
	         $date=time();
	        $file = $_FILES['file']['name'];
         $file_loc = $_FILES['file']['tmp_name'];
           $file_size = $_FILES['file']['size'];
          $file_type = $_FILES['file']['type'];
	       move_uploaded_file($_FILES["file"]["tmp_name"],"../images/$file");
	       if(strlen($pass>=8))
    {
	$ms="<p style='color:red;'>Password has been 8 charactar!</p>";
	  
	}
	else
	if($pass != $rpass)
    {
	

	$mg= "<p style='color:red;'>Password dose not match please chek the password!</p>";
	 
	}else
	{
		
	
			 $chek_query="select * from login where Email='$email'";
			 $chek_run=mysqli_query($con,$chek_query);
			 if(mysqli_num_rows($chek_run)==1)
			 {
			 	$msg="<p style='color:red;'>Email alredy regesterd please try an author Email</p>";
			 }
			 else {
			 	
			 
			$s="INSERT INTO `login` ( `name`, `Email`, `password`, `role`, `images`, `discripation`, `date`, `dob`) VALUES ( '$name','$email','$pass', '$rol', '$file', '$dic', '$date', '$dob')";
if(isset($_SESSION['user'])&& $_SESSION['role']== 'Administrater')
{
	$run=mysqli_query($con,$s) ;
	if($run)
	{
		echo "<script>window.location='User.php';</script>";
	}
	}else
	{
		header('location:Admin.php');
	}
		}
		 }
		 }
		?>
	<div class="col-lg-12 col-md-12 col-xs-12">
	<div  style="color:#ffff ; background-color: #ea6a15;">
	<h2 class="text-center text-bold">Add new User</h2>
	</div>
	<div style="margin-top: 20px;">
		<form action="Add_user.php" method="post" enctype="multipart/form-data">
			<div class="form-group">
			<label>Name</label>
				<input  type="text" name="name"  value="<?php if(isset($name)){echo $name;}?>" class="form-control" required=""  placeholder="Enter name"/>
			</div>
			<div class="form-group">
			<label>Date of borth </label>
			
		<input  type="date" name="dob" class="form-control" required=""  value="<?php if(isset($dob)){echo $dob;}?>"/> 
			</div>
			<div class="form-group">
			<label>Password</label>
				<input  type="password" name="pass"class="form-control" required="" value="<?php if(isset($pass)){echo $pass;}?>"  placeholder="Enter Password"/>
				<?php if(isset($ms))
				{
					echo $ms;
				}
				?>
			</div>
			<div class="form-group">
			<label>Re-Password</label>
				<input  type="password" name="rpass"class="form-control" required=""  value="<?php if(isset($rpass)){echo $rpass;}?>" placeholder="Enter Password"/>    
				<?php if(isset($mg))
				{
					echo $mg;
				}
				?>
			</div>
			<div class="form-group">
			<label>Email</label>
				<input  type="email" name="email" class="form-control" required=""  value="<?php if(isset($email)){echo $email;}?>" placeholder="Enter Email" />
				<?php if(isset($msg))
				{
					echo $msg;
				}
				?>
			</div>
			<div class="form-group">
			<label>Image</label>
				<input  type="file" name="file" class="form-control" required/>
			</div>
			<div class="form-group">
			<label>Role</label>
				<select name="role" class="form-control" required >
              <option>choose the Role</option>
                 <option value="Administrater">Administrater</option>
				  <option value="local">local</option>
            </select>
			</div>
			<div class="form-group">
			<label>Discripation</label>
				<textarea type="text" name="dic" rows="20" cols="20" class="form-control textme"> <?php if(isset($dic)){echo $dic;}?></textarea>
			</div>
			<div class="form-group">
				<input  type="submit" name="submit" value="Add User" class="btn btn-primary" />
			</div>
		</form>
		</div>
  </div>
  
  </div>
    </div>
  </div>
</div>
  <?php include_once("inc/footer.php");?>
</body>
</html>
<?php 
}
else{
	header("location:index.php");
}
?>