<?php
session_start();
$nam=$_SESSION['user'];
if(isset($_SESSION['user']))
{
	

?>
<!doctype html>
<html>
<head>
<?php require_once("inc/top.php"); ?>
<style>
	.mt
	{
		margin-top:100px;
		 
	}
	td a{
		padding: 30px;
	}
	.mar{
		padding-top: 70px;
	
	}
</style>
</head>

<body>
<?php require_once("inc/header.php");?>
<div class="container-fluid my-fluid" >
	<div class="row">
		<?php require_once("inc/aside-bar.php"); ?>
		<div class="col-lg-9 leftm col-md-9  col-xs-12 " style="margin-top: 40px;">
			<div class="page-header">
			
  <h1>Categories <small>Subtext for header</small></h1>
</div>
	<ol class="breadcrumb">
  <li><a href="#"> <i class="fa fa-folder" aria-hidden="true"></i> Categories</a></li>

</ol>
     
		<hr>
		
		<div class="row">
		
			<div class="col-md-7">
			
			<?php
						if(isset($_POST['nsub']))
			{
			
			$cat_name=$_POST['cat'];
			$s_query="select * from login where Email='$nam'";
			$s_run=mysqli_query($con,$s_query);
			$s_fetch=mysqli_fetch_array($s_run);
			 $id_cat=$s_fetch['Id'];
			$cat_ins="INSERT INTO `categories` (`categories`,`login_id`) VALUES ('$cat_name','$id_cat')";
			$ins_run=mysqli_query($con,$cat_ins);
			if($ins_run)
			{
				$msg= "data save";
				header('location:categories.php');
			}
			else{
				$error_msg="nota data save";
			}
				
			}
					?>
					<?php if(isset($msg)){
	?>
	<div class="alert alert-success" role="alert"><?php echo $msg; ?></div>
	
	<?php 
	}
	else 
	if(isset($error_sms)){
		
		?>
		<div class="alert alert-danger" role="alert"><?php   echo $error_sms; ?></div>
	
	<?php } ?>
				<form action="" method="post" enctype="multipart/form-data">
			<div class="row">
				<div class="col-lg-4 ">
					<div class="form-group">	
						<input  type="text" name="cat" class="form-control" required="" placeholder="Enter the Categories"/>
					</div>
				</div>
				<div class="col-lg-8">
					<input type="submit" name="nsub" class="btn btn-success" value="Add">
				</div>
				
			</div>
		</form>
			</div>
			<div class="col-md-5">
	
		<form action="" method="post" enctype="multipart/form-data">
			<div class="row">
				<div class="col-lg-4 ">
					<div class="form-group">	
						<select class="form-control" id=""  name="delete">
							<option>-Select-</option>
							<?php if(isset($_SESSION['user'])&& $_SESSION['role']== 'Administrater')
{?>
							<option value="delete" >Delete</option>
							<?php }?>
						</select>
					</div>
				</div>
				<div class="col-lg-8">
					<input type="submit" name="del" class="btn btn-success" value="Apply">
				</div>
		
		<div class="widget mar">

   				<div class="input-group">
   					<input type="text" class="form-control"  name="serch" placeholder="search here.....">
   					<span class="input-group-btn">
   						<input type="submit" name="submit" class="btn btn-default" value="Go!">
   					</span>
   				</div>
	
   		
	</div>
				<?php
				if(isset($_POST['del']))
				{
					
					$del= $_POST['delete'];
					if(isset($_POST['chek']))
					{
						$check =$_POST['chek'];
					for($i=0; $i<count($check); $i++)
					{
						 $c_id2 = $check[$i];	
						 if('delete'== $del)
						 {
						 	$del_qu="delete from categories where id='$c_id2'";
						 	$run_d=mysqli_query($con,$del_qu);
						 }
			             else{
						 	//$msg="Please Select Row ";
						 }
					}
				}
				else
					{
						echo '<P style="color:red;">please select row</P>';
					}
				}
				?>
				
			</div>
		    <!--<p style="color:red;"><?php echo $msg ;?></p>-->
	
			<?php 
			if(isset($_POST['submit']))
			{
				$cont=$_POST['serch'];
				$cat_query="select * FROM categories WHERE";
				$cat_query .=" categories like '%$cont%'";
				$cat_query .="order by id DESC";
			}
			else{
				$cat_query="select * from categories order by id DESC";
			}
					
					$cat_run=mysqli_query($con,$cat_query);
					if(mysqli_num_rows($cat_run)>0)
					{
				
					
					?>
			<div class="table-responsive">
				<table class="table table-hover mt table-bordered">
			<thead align="center">
				<tr>
				<th><input type="checkbox" name="chek" id="select_all"></th>
				
					<th>Cotegories</th>
					<th>Edit</th>
					<th>Delete</th>
				</tr>
			</thead>
			<tbody align="center">
				<?php 
				while($row_cat=mysqli_fetch_array($cat_run))
				{
					$cat_id=$row_cat['id'];
					$cat_log_id=$row_cat['login_id'];
					$cat_cat=$row_cat['categories'];
				
				?>
				
				<tr>
				<td><input type="checkbox" name="chek[]" value="<?php echo $cat_id;?>" class="checkbox"></td>
					
					<td><?php echo $cat_cat ; ?></td>
					<?php 
					
					$sq="select* from login where Email='$nam'";
					$sr=mysqli_query($con,$sq);
					$rus=mysqli_fetch_array($sr);
					 $id4=$rus['Id'];
					 if($id4==$cat_log_id or $_SESSION['role']=='Administrater')
					 {
					 	
					 
					?>
					<td><a href="cot-edit.php?edt=<?php echo $cat_id ;?>" ><i class="fa fa-pencil"></i></a></td>
					<?php } else 
					{
					
					?>
					<td><a href=""><i class="fa fa-pencil"></i></a></td>
					<?php }?>
				
					<?php 
					
					if(isset($_GET['c_id']))
					{
						$c_id=$_GET['c_id'];
						$delete_cat="DELETE FROM `categories` WHERE `categories`.`id` = '$c_id'";
						if(isset($_SESSION['user'])&& $_SESSION['role']== 'Administrater')
{
						$d_run=mysqli_query($con,$delete_cat);
						}
						else
						{
							header('location:Admin.php');
						}
					}
					?>
					<td><a href="categories.php?c_id=<?php echo $cat_id ; ?>"><i class="fa fa-times"></i></a></td>
					
				</tr>
				<?php } ?>
			</tbody>
		</table>
		</div>
		<?php } else
		{
			echo"<h2 style='color:red; text-align:center; margin-top:140px; margin-bottom:140px;'>Sorry no data yet !</h2>";
		}?>
			</form>
			</div>
		
		</div>
		
		</div>
		
			
		</div>
		
		</div>
		<?php require_once("inc/footer.php"); ?>
	
	

</body>
</html>
<?php
	}
else
{
	echo "<script>window.open('index.php','_self')</script>";
}
	?>